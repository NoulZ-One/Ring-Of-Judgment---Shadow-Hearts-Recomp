#pragma once
#include <cstdint>
#include <cstring>
#include <cmath>

// Registrador de 128 bits do EE. As operacoes de 64 bits usam so o lo.
struct Reg128 { uint64_t lo; uint64_t hi; };

struct Ctx
{
    Reg128 r[32];     // r[0] nunca e escrito: o codigo gerado pula escritas em $zero
    uint64_t hi, lo;  // HI/LO (pipeline 0)
    uint64_t hi1, lo1;  // HI1/LO1 (pipeline 1)
    uint32_t sa;      // registrador SA (QFSRV): deslocamento em bits
    uint32_t f[32];   // registradores da FPU, como bits de float
    uint32_t acc;     // acumulador da FPU
    uint32_t fcr31;   // controle da FPU: bit 23 = condicao (C)
    uint32_t vf[32][4];  // VU0: registradores VF (x, y, z, w) como bits de float
    uint32_t vacc[4];    // VU0: acumulador
    uint32_t vi[32];     // VU0: VI0..VI15 (16 bits) e controle: 16 status, 17 MAC, 18 clip, 20 R, 21 I, 22 Q, 23 P, 27 CMSAR0
    uint8_t* mem;     // RAM do EE (32 MB) no host
};

static inline uint64_t S32(uint32_t v) { return (uint64_t)(int64_t)(int32_t)v; }

// Traducao de endereco provisoria: so RAM (e seus espelhos).
// Registradores de hardware e scratchpad precisam de despacho proprio.
static inline uint8_t* host(Ctx& c, uint32_t addr) { return c.mem + (addr & 0x01FFFFFFu); }

template <class T> static inline T mrd(Ctx& c, uint32_t addr)
{
    T v;
    std::memcpy(&v, host(c, addr), sizeof(T));
    return v;
}

template <class T> static inline void mwr(Ctx& c, uint32_t addr, T v)
{
    std::memcpy(host(c, addr), &v, sizeof(T));
}

// ---- multiplicacao e divisao inteira (EE: MULT/MULTU tambem gravam rd) ----
// As variantes 1 usam o segundo par HI1/LO1 (pipeline 1).

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_mult_t(Ctx& c, int rd, int rs, int rt)
{
    int64_t p = (int64_t)(int32_t)c.r[rs].lo * (int64_t)(int32_t)c.r[rt].lo;
    c.*LO = S32((uint32_t)p);
    c.*HI = S32((uint32_t)((uint64_t)p >> 32));
    if (rd != 0) c.r[rd].lo = c.*LO;
}

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_multu_t(Ctx& c, int rd, int rs, int rt)
{
    uint64_t p = (uint64_t)(uint32_t)c.r[rs].lo * (uint64_t)(uint32_t)c.r[rt].lo;
    c.*LO = S32((uint32_t)p);
    c.*HI = S32((uint32_t)(p >> 32));
    if (rd != 0) c.r[rd].lo = c.*LO;
}

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_div_t(Ctx& c, int rs, int rt)
{
    int32_t a = (int32_t)c.r[rs].lo;
    int32_t b = (int32_t)c.r[rt].lo;
    if (b == 0)
    {
        c.*LO = S32(a >= 0 ? 0xFFFFFFFFu : 1u);
        c.*HI = S32((uint32_t)a);
    }
    else if (a == INT32_MIN && b == -1)
    {
        c.*LO = S32(0x80000000u);
        c.*HI = 0;
    }
    else
    {
        c.*LO = S32((uint32_t)(a / b));
        c.*HI = S32((uint32_t)(a % b));
    }
}

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_divu_t(Ctx& c, int rs, int rt)
{
    uint32_t a = (uint32_t)c.r[rs].lo;
    uint32_t b = (uint32_t)c.r[rt].lo;
    if (b == 0)
    {
        c.*LO = S32(0xFFFFFFFFu);
        c.*HI = S32(a);
    }
    else
    {
        c.*LO = S32(a / b);
        c.*HI = S32(a % b);
    }
}

static inline void ee_mult(Ctx& c, int rd, int rs, int rt)   { ee_mult_t<&Ctx::hi, &Ctx::lo>(c, rd, rs, rt); }
static inline void ee_multu(Ctx& c, int rd, int rs, int rt)  { ee_multu_t<&Ctx::hi, &Ctx::lo>(c, rd, rs, rt); }
static inline void ee_div(Ctx& c, int rs, int rt)            { ee_div_t<&Ctx::hi, &Ctx::lo>(c, rs, rt); }
static inline void ee_divu(Ctx& c, int rs, int rt)           { ee_divu_t<&Ctx::hi, &Ctx::lo>(c, rs, rt); }
static inline void ee_mult1(Ctx& c, int rd, int rs, int rt)  { ee_mult_t<&Ctx::hi1, &Ctx::lo1>(c, rd, rs, rt); }
static inline void ee_multu1(Ctx& c, int rd, int rs, int rt) { ee_multu_t<&Ctx::hi1, &Ctx::lo1>(c, rd, rs, rt); }
static inline void ee_div1(Ctx& c, int rs, int rt)           { ee_div_t<&Ctx::hi1, &Ctx::lo1>(c, rs, rt); }
static inline void ee_divu1(Ctx& c, int rs, int rt)          { ee_divu_t<&Ctx::hi1, &Ctx::lo1>(c, rs, rt); }

// ---- cargas e gravacoes desalinhadas (little-endian) ----

static inline void ee_lwl(Ctx& c, int rt, uint32_t addr)
{
    uint32_t w = mrd<uint32_t>(c, addr & ~3u);
    uint32_t s = addr & 3u;
    uint32_t r = ((uint32_t)c.r[rt].lo & (0x00FFFFFFu >> (8 * s))) | (w << (24 - 8 * s));
    c.r[rt].lo = S32(r);
}

static inline void ee_lwr(Ctx& c, int rt, uint32_t addr)
{
    uint32_t w = mrd<uint32_t>(c, addr & ~3u);
    uint32_t s = addr & 3u;
    uint32_t r = ((uint32_t)c.r[rt].lo & (0xFFFFFF00u << (24 - 8 * s))) | (w >> (8 * s));
    if (s == 0) c.r[rt].lo = S32(r);
    else c.r[rt].lo = (c.r[rt].lo & 0xFFFFFFFF00000000ull) | r;
}

static inline void ee_swl(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~3u;
    uint32_t s = addr & 3u;
    uint32_t w = mrd<uint32_t>(c, a);
    w = (w & (0xFFFFFF00u << (8 * s))) | ((uint32_t)c.r[rt].lo >> (24 - 8 * s));
    mwr<uint32_t>(c, a, w);
}

static inline void ee_swr(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~3u;
    uint32_t s = addr & 3u;
    uint32_t w = mrd<uint32_t>(c, a);
    w = (w & (0x00FFFFFFu >> (24 - 8 * s))) | ((uint32_t)c.r[rt].lo << (8 * s));
    mwr<uint32_t>(c, a, w);
}

static inline void ee_ldl(Ctx& c, int rt, uint32_t addr)
{
    uint64_t d = mrd<uint64_t>(c, addr & ~7u);
    uint32_t s = addr & 7u;
    c.r[rt].lo = (c.r[rt].lo & (0x00FFFFFFFFFFFFFFull >> (8 * s))) | (d << (56 - 8 * s));
}

static inline void ee_ldr(Ctx& c, int rt, uint32_t addr)
{
    uint64_t d = mrd<uint64_t>(c, addr & ~7u);
    uint32_t s = addr & 7u;
    c.r[rt].lo = (c.r[rt].lo & (0xFFFFFFFFFFFFFF00ull << (56 - 8 * s))) | (d >> (8 * s));
}

static inline void ee_sdl(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~7u;
    uint32_t s = addr & 7u;
    uint64_t d = mrd<uint64_t>(c, a);
    d = (d & (0xFFFFFFFFFFFFFF00ull << (8 * s))) | (c.r[rt].lo >> (56 - 8 * s));
    mwr<uint64_t>(c, a, d);
}

static inline void ee_sdr(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~7u;
    uint32_t s = addr & 7u;
    uint64_t d = mrd<uint64_t>(c, a);
    d = (d & (0x00FFFFFFFFFFFFFFull >> (56 - 8 * s))) | (c.r[rt].lo << (8 * s));
    mwr<uint64_t>(c, a, d);
}

// ---- FPU do EE: so precisao simples, sem NaN/Inf/denormais ----
// Entradas Inf/NaN viram +-FLT_MAX e denormais viram +-0. Resultados saturam em
// +-FLT_MAX e sao truncados em direcao a zero. Flags de excecao ainda ignoradas.

static inline float f32(uint32_t b) { float v; std::memcpy(&v, &b, 4); return v; }
static inline uint32_t u32(float v) { uint32_t b; std::memcpy(&b, &v, 4); return b; }

static inline double ee_in(uint32_t b)
{
    uint32_t e = b & 0x7F800000u;
    if (e == 0) return (b & 0x80000000u) ? -0.0 : 0.0;
    if (e == 0x7F800000u) b = (b & 0x80000000u) | 0x7F7FFFFFu;
    return (double)f32(b);
}

static inline uint32_t ee_pack(double v)
{
    const double MAXF = 3.4028234663852886e+38;
    if (v != v) v = 0.0;
    if (v > MAXF) v = MAXF;
    else if (v < -MAXF) v = -MAXF;

    float r = (float)v;
    if (std::fabs((double)r) > std::fabs(v))
        r = std::nextafterf(r, 0.0f);

    uint32_t b = u32(r);
    if ((b & 0x7F800000u) == 0) b &= 0x80000000u;
    return b;
}

static inline void fpu_set_c(Ctx& c, bool v)
{
    if (v) c.fcr31 |= 0x00800000u; else c.fcr31 &= ~0x00800000u;
}

static inline void fpu_add(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.f[fs]) + ee_in(c.f[ft])); }
static inline void fpu_sub(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.f[fs]) - ee_in(c.f[ft])); }
static inline void fpu_mul(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.f[fs]) * ee_in(c.f[ft])); }

static inline void fpu_div(Ctx& c, int fd, int fs, int ft)
{
    double d = ee_in(c.f[ft]);
    if (d == 0.0) { c.f[fd] = ((c.f[fs] ^ c.f[ft]) & 0x80000000u) | 0x7F7FFFFFu; return; }
    c.f[fd] = ee_pack(ee_in(c.f[fs]) / d);
}

static inline void fpu_sqrt(Ctx& c, int fd, int ft)
{
    c.f[fd] = ee_pack(std::sqrt(std::fabs(ee_in(c.f[ft]))));
}

static inline void fpu_rsqrt(Ctx& c, int fd, int fs, int ft)
{
    double d = std::sqrt(std::fabs(ee_in(c.f[ft])));
    if (d == 0.0) { c.f[fd] = (c.f[fs] & 0x80000000u) | 0x7F7FFFFFu; return; }
    c.f[fd] = ee_pack(ee_in(c.f[fs]) / d);
}

static inline void fpu_max(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_in(c.f[fs]) > ee_in(c.f[ft]) ? c.f[fs] : c.f[ft]; }
static inline void fpu_min(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_in(c.f[fs]) < ee_in(c.f[ft]) ? c.f[fs] : c.f[ft]; }

static inline void fpu_adda(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.f[fs]) + ee_in(c.f[ft])); }
static inline void fpu_suba(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.f[fs]) - ee_in(c.f[ft])); }
static inline void fpu_mula(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_madd(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.acc) + ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_msub(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.acc) - ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_madda(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.acc) + ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_msuba(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.acc) - ee_in(c.f[fs]) * ee_in(c.f[ft])); }

static inline void fpu_cvt_s_w(Ctx& c, int fd, int fs) { c.f[fd] = ee_pack((double)(int32_t)c.f[fs]); }

static inline void fpu_cvt_w_s(Ctx& c, int fd, int fs)
{
    double v = ee_in(c.f[fs]);
    if (v >= 2147483648.0) c.f[fd] = 0x7FFFFFFFu;
    else if (v <= -2147483648.0) c.f[fd] = 0x80000000u;
    else c.f[fd] = (uint32_t)(int32_t)v;
}

static inline void fpu_c_eq(Ctx& c, int fs, int ft) { fpu_set_c(c, ee_in(c.f[fs]) == ee_in(c.f[ft])); }
static inline void fpu_c_lt(Ctx& c, int fs, int ft) { fpu_set_c(c, ee_in(c.f[fs]) < ee_in(c.f[ft])); }
static inline void fpu_c_le(Ctx& c, int fs, int ft) { fpu_set_c(c, ee_in(c.f[fs]) <= ee_in(c.f[ft])); }

// ---- VU0 em modo macro (COP2) ----
// Chame vu0_init(c) uma vez no inicio: VF0 e sempre (0, 0, 0, 1).
// Flags MAC e status ainda nao sao calculadas; o clip (VCLIPw) e exato.
// As variaveis Q, I e P ficam em vi[22], vi[21] e vi[23].

enum { VU_ADD, VU_SUB, VU_MUL, VU_MADD, VU_MSUB, VU_MAX, VU_MIN };
enum { VU_SRC_VEC, VU_SRC_X, VU_SRC_Y, VU_SRC_Z, VU_SRC_W, VU_SRC_Q, VU_SRC_I };

static inline void vu0_init(Ctx& c)
{
    c.vf[0][0] = 0; c.vf[0][1] = 0; c.vf[0][2] = 0; c.vf[0][3] = 0x3F800000u;
}

static inline Reg128 vu_qmfc2(Ctx& c, int vf)
{
    Reg128 r;
    std::memcpy(&r, c.vf[vf], 16);
    return r;
}

static inline void vu_qmtc2(Ctx& c, int vf, Reg128 r)
{
    if (vf != 0) std::memcpy(c.vf[vf], &r, 16);
}

static inline uint32_t vu_cfc2(Ctx& c, int r)
{
    if (r == 0) return 0;
    if (r < 16) return c.vi[r] & 0xFFFFu;
    return c.vi[r & 31];
}

static inline void vu_ctc2(Ctx& c, int r, uint32_t v)
{
    if (r == 0) return;
    if (r < 16) c.vi[r] = v & 0xFFFFu;
    else if (r == 18) c.vi[18] = v & 0xFFFFFFu;
    else c.vi[r & 31] = v;
}

// Aritmetica por faixa: fd = fs OP fonte. Com to_acc, grava no acumulador.
// MADD/MSUB usam o acumulador como parcela. So as faixas de dest (x=8 .. w=1) mudam.
static inline void vu_arith(Ctx& c, int op, int src, int dest, int fd, int fs, int ft, int to_acc)
{
    uint32_t res[4];
    for (int l = 0; l < 4; l++)
    {
        uint32_t a = c.vf[fs][l];
        uint32_t b;
        switch (src)
        {
            case VU_SRC_VEC: b = c.vf[ft][l]; break;
            case VU_SRC_X:   b = c.vf[ft][0]; break;
            case VU_SRC_Y:   b = c.vf[ft][1]; break;
            case VU_SRC_Z:   b = c.vf[ft][2]; break;
            case VU_SRC_W:   b = c.vf[ft][3]; break;
            case VU_SRC_Q:   b = c.vi[22]; break;
            default:         b = c.vi[21]; break;
        }
        switch (op)
        {
            case VU_ADD:  res[l] = ee_pack(ee_in(a) + ee_in(b)); break;
            case VU_SUB:  res[l] = ee_pack(ee_in(a) - ee_in(b)); break;
            case VU_MUL:  res[l] = ee_pack(ee_in(a) * ee_in(b)); break;
            case VU_MADD: res[l] = ee_pack(ee_in(c.vacc[l]) + ee_in(a) * ee_in(b)); break;
            case VU_MSUB: res[l] = ee_pack(ee_in(c.vacc[l]) - ee_in(a) * ee_in(b)); break;
            case VU_MAX:  res[l] = ee_in(a) > ee_in(b) ? a : b; break;
            default:      res[l] = ee_in(a) < ee_in(b) ? a : b; break;
        }
    }
    for (int l = 0; l < 4; l++)
    {
        if (!(dest & (8 >> l))) continue;
        if (to_acc) c.vacc[l] = res[l];
        else if (fd != 0) c.vf[fd][l] = res[l];
    }
}

// Produto vetorial: OPMULA grava no acumulador, OPMSUB subtrai dele (so xyz).
static inline void vu_opmula(Ctx& c, int fs, int ft)
{
    uint32_t x = ee_pack(ee_in(c.vf[fs][1]) * ee_in(c.vf[ft][2]));
    uint32_t y = ee_pack(ee_in(c.vf[fs][2]) * ee_in(c.vf[ft][0]));
    uint32_t z = ee_pack(ee_in(c.vf[fs][0]) * ee_in(c.vf[ft][1]));
    c.vacc[0] = x; c.vacc[1] = y; c.vacc[2] = z;
}

static inline void vu_opmsub(Ctx& c, int fd, int fs, int ft)
{
    uint32_t x = ee_pack(ee_in(c.vacc[0]) - ee_in(c.vf[fs][1]) * ee_in(c.vf[ft][2]));
    uint32_t y = ee_pack(ee_in(c.vacc[1]) - ee_in(c.vf[fs][2]) * ee_in(c.vf[ft][0]));
    uint32_t z = ee_pack(ee_in(c.vacc[2]) - ee_in(c.vf[fs][0]) * ee_in(c.vf[ft][1]));
    if (fd != 0) { c.vf[fd][0] = x; c.vf[fd][1] = y; c.vf[fd][2] = z; }
}

static inline void vu_move(Ctx& c, int dest, int ft, int fs)
{
    uint32_t t[4] = { c.vf[fs][0], c.vf[fs][1], c.vf[fs][2], c.vf[fs][3] };
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

static inline void vu_mr32(Ctx& c, int dest, int ft, int fs)
{
    uint32_t t[4] = { c.vf[fs][1], c.vf[fs][2], c.vf[fs][3], c.vf[fs][0] };
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

static inline void vu_abs(Ctx& c, int dest, int ft, int fs)
{
    uint32_t t[4] = { c.vf[fs][0], c.vf[fs][1], c.vf[fs][2], c.vf[fs][3] };
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l] & 0x7FFFFFFFu;
}

// Inteiro para float com n bits fracionarios (n = 0, 4, 12, 15), e o inverso (trunca e satura).
static inline void vu_itof(Ctx& c, int dest, int ft, int fs, int n)
{
    uint32_t t[4];
    for (int l = 0; l < 4; l++) t[l] = ee_pack((double)(int32_t)c.vf[fs][l] / (double)(1 << n));
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

static inline void vu_ftoi(Ctx& c, int dest, int ft, int fs, int n)
{
    uint32_t t[4];
    for (int l = 0; l < 4; l++)
    {
        double v = ee_in(c.vf[fs][l]) * (double)(1 << n);
        if (v >= 2147483648.0) t[l] = 0x7FFFFFFFu;
        else if (v <= -2147483648.0) t[l] = 0x80000000u;
        else t[l] = (uint32_t)(int32_t)v;
    }
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

// VCLIPw: compara fs.xyz com |ft.w| e empilha 6 bits no historico de clip (24 bits).
static inline void vu_clipw(Ctx& c, int fs, int ft)
{
    double w = std::fabs(ee_in(c.vf[ft][3]));
    double x = ee_in(c.vf[fs][0]);
    double y = ee_in(c.vf[fs][1]);
    double z = ee_in(c.vf[fs][2]);
    uint32_t clip = (c.vi[18] << 6) & 0xFFFFFFu;
    if (x > w) clip |= 0x01u;
    if (x < -w) clip |= 0x02u;
    if (y > w) clip |= 0x04u;
    if (y < -w) clip |= 0x08u;
    if (z > w) clip |= 0x10u;
    if (z < -w) clip |= 0x20u;
    c.vi[18] = clip;
}

// Q = fs.fsf / ft.ftf. Divisor zero satura em +-FLT_MAX com o sinal do xor.
static inline void vu_div(Ctx& c, int fs, int fsf, int ft, int ftf)
{
    uint32_t a = c.vf[fs][fsf];
    uint32_t b = c.vf[ft][ftf];
    double d = ee_in(b);
    if (d == 0.0) c.vi[22] = ((a ^ b) & 0x80000000u) | 0x7F7FFFFFu;
    else c.vi[22] = ee_pack(ee_in(a) / d);
}

static inline void vu_sqrt(Ctx& c, int ft, int ftf)
{
    c.vi[22] = ee_pack(std::sqrt(std::fabs(ee_in(c.vf[ft][ftf]))));
}

static inline void vu_rsqrt(Ctx& c, int fs, int fsf, int ft, int ftf)
{
    uint32_t a = c.vf[fs][fsf];
    uint32_t b = c.vf[ft][ftf];
    double d = std::sqrt(std::fabs(ee_in(b)));
    if (d == 0.0) c.vi[22] = ((a ^ b) & 0x80000000u) | 0x7F7FFFFFu;
    else c.vi[22] = ee_pack(ee_in(a) / d);
}

// Inteiros do VU0 (16 bits; VI0 e sempre 0).
static inline void vu_vi_set(Ctx& c, int r, uint32_t v) { if (r != 0) c.vi[r] = v & 0xFFFFu; }
static inline void vu_iadd(Ctx& c, int id, int is, int it) { vu_vi_set(c, id, c.vi[is] + c.vi[it]); }
static inline void vu_isub(Ctx& c, int id, int is, int it) { vu_vi_set(c, id, c.vi[is] - c.vi[it]); }
static inline void vu_iand(Ctx& c, int id, int is, int it) { vu_vi_set(c, id, c.vi[is] & c.vi[it]); }
static inline void vu_ior(Ctx& c, int id, int is, int it)  { vu_vi_set(c, id, c.vi[is] | c.vi[it]); }
static inline void vu_iaddi(Ctx& c, int it, int is, int imm5) { vu_vi_set(c, it, c.vi[is] + (uint32_t)imm5); }
static inline void vu_mtir(Ctx& c, int it, int fs, int fsf) { vu_vi_set(c, it, c.vf[fs][fsf]); }

static inline void vu_mfir(Ctx& c, int dest, int ft, int is)
{
    uint32_t v = (uint32_t)(int32_t)(int16_t)c.vi[is];
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = v;
}

// ---- MMI: operacoes paralelas sobre os 128 bits ----

union V128 { Reg128 r; uint8_t b[16]; uint16_t h[8]; uint32_t w[4]; uint64_t d[2]; };

static inline V128 V(const Reg128& r) { V128 v; v.r = r; return v; }

static inline void mmi_pand(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rs].lo & c.r[rt].lo, c.r[rs].hi & c.r[rt].hi }; c.r[rd] = o; }
static inline void mmi_por(Ctx& c, int rd, int rs, int rt)  { Reg128 o = { c.r[rs].lo | c.r[rt].lo, c.r[rs].hi | c.r[rt].hi }; c.r[rd] = o; }
static inline void mmi_pxor(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rs].lo ^ c.r[rt].lo, c.r[rs].hi ^ c.r[rt].hi }; c.r[rd] = o; }
static inline void mmi_pnor(Ctx& c, int rd, int rs, int rt) { Reg128 o = { ~(c.r[rs].lo | c.r[rt].lo), ~(c.r[rs].hi | c.r[rt].hi) }; c.r[rd] = o; }

static inline void mmi_pcpyld(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rt].lo, c.r[rs].lo }; c.r[rd] = o; }
static inline void mmi_pcpyud(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rs].hi, c.r[rt].hi }; c.r[rd] = o; }

static inline void mmi_paddw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] + b.w[i]; c.r[rd] = o.r; }
static inline void mmi_psubw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] - b.w[i]; c.r[rd] = o.r; }
static inline void mmi_paddh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] + b.h[i]); c.r[rd] = o.r; }
static inline void mmi_psubh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] - b.h[i]); c.r[rd] = o.r; }
static inline void mmi_paddb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 16; i++) o.b[i] = (uint8_t)(a.b[i] + b.b[i]); c.r[rd] = o.r; }
static inline void mmi_psubb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 16; i++) o.b[i] = (uint8_t)(a.b[i] - b.b[i]); c.r[rd] = o.r; }

// PADDUB: soma de bytes sem sinal com saturacao em 255 (com rt = $zero e uma copia de 128 bits).
static inline void mmi_paddub(Ctx& c, int rd, int rs, int rt)
{
    V128 a = V(c.r[rs]), b = V(c.r[rt]), o;
    for (int i = 0; i < 16; i++) { unsigned v = (unsigned)a.b[i] + b.b[i]; o.b[i] = (uint8_t)(v > 255u ? 255u : v); }
    c.r[rd] = o.r;
}

// Deslocamentos por constante (rd, rt, sa).
static inline void mmi_psllh(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] << (sa & 15)); c.r[rd] = o.r; }
static inline void mmi_psrlh(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] >> (sa & 15)); c.r[rd] = o.r; }
static inline void mmi_psrah(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)((int16_t)a.h[i] >> (sa & 15)); c.r[rd] = o.r; }
static inline void mmi_psllw(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] << (sa & 31); c.r[rd] = o.r; }
static inline void mmi_psrlw(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] >> (sa & 31); c.r[rd] = o.r; }
static inline void mmi_psraw(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = (uint32_t)((int32_t)a.w[i] >> (sa & 31)); c.r[rd] = o.r; }

// Intercalacao: rt fica nas posicoes pares e rs nas impares.
static inline void mmi_pextlb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { o.b[2 * i] = b.b[i];     o.b[2 * i + 1] = a.b[i]; }     c.r[rd] = o.r; }
static inline void mmi_pextub(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { o.b[2 * i] = b.b[8 + i]; o.b[2 * i + 1] = a.b[8 + i]; } c.r[rd] = o.r; }
static inline void mmi_pextlh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[2 * i] = b.h[i];     o.h[2 * i + 1] = a.h[i]; }     c.r[rd] = o.r; }
static inline void mmi_pextuh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[2 * i] = b.h[4 + i]; o.h[2 * i + 1] = a.h[4 + i]; } c.r[rd] = o.r; }
static inline void mmi_pextlw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 2; i++) { o.w[2 * i] = b.w[i];     o.w[2 * i + 1] = a.w[i]; }     c.r[rd] = o.r; }
static inline void mmi_pextuw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 2; i++) { o.w[2 * i] = b.w[2 + i]; o.w[2 * i + 1] = a.w[2 + i]; } c.r[rd] = o.r; }

// QFSRV: ({rs, rt} >> SA)[127:0]. SA vem de MTSAB/MTSAH.
static inline Reg128 shr128(Reg128 v, unsigned n)
{
    if (n == 0) return v;
    Reg128 o;
    if (n < 64) { o.lo = (v.lo >> n) | (v.hi << (64 - n)); o.hi = v.hi >> n; }
    else        { o.lo = v.hi >> (n - 64); o.hi = 0; }
    return o;
}

static inline Reg128 shl128(Reg128 v, unsigned n)
{
    if (n == 0) return v;
    Reg128 o;
    if (n < 64) { o.hi = (v.hi << n) | (v.lo >> (64 - n)); o.lo = v.lo << n; }
    else        { o.hi = v.lo << (n - 64); o.lo = 0; }
    return o;
}

static inline void mmi_qfsrv(Ctx& c, int rd, int rs, int rt)
{
    unsigned sa = c.sa & 127u;
    Reg128 lo = shr128(c.r[rt], sa);
    Reg128 hi = sa == 0 ? Reg128{0, 0} : shl128(c.r[rs], 128 - sa);
    Reg128 o = { lo.lo | hi.lo, lo.hi | hi.hi };
    c.r[rd] = o;
}

static inline void ee_mtsab(Ctx& c, int rs, uint32_t imm) { c.sa = (((uint32_t)c.r[rs].lo & 15u) ^ (imm & 15u)) * 8u; }
static inline void ee_mtsah(Ctx& c, int rs, uint32_t imm) { c.sa = (((uint32_t)c.r[rs].lo & 7u) ^ (imm & 7u)) * 16u; }

// ---- MMI: comparacoes, min/max, pack e trocas ----

static inline void mmi_pcgth(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (int16_t)a.h[i] > (int16_t)b.h[i] ? 0xFFFFu : 0u; c.r[rd] = o.r; }
static inline void mmi_pminh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (int16_t)a.h[i] < (int16_t)b.h[i] ? a.h[i] : b.h[i]; c.r[rd] = o.r; }
static inline void mmi_pmaxh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (int16_t)a.h[i] > (int16_t)b.h[i] ? a.h[i] : b.h[i]; c.r[rd] = o.r; }
static inline void mmi_pminw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = (int32_t)a.w[i] < (int32_t)b.w[i] ? a.w[i] : b.w[i]; c.r[rd] = o.r; }

// Saturacao sem sinal: PSUBUB fica em 0, PADDUH fica em 0xFFFF.
static inline void mmi_psubub(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 16; i++) o.b[i] = (uint8_t)(a.b[i] > b.b[i] ? a.b[i] - b.b[i] : 0); c.r[rd] = o.r; }
static inline void mmi_padduh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { unsigned v = (unsigned)a.h[i] + b.h[i]; o.h[i] = (uint16_t)(v > 0xFFFFu ? 0xFFFFu : v); } c.r[rd] = o.r; }

// PPACB/PPACH: pega os elementos pares; rt vai para a metade baixa e rs para a alta.
static inline void mmi_ppacb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { o.b[i] = b.b[2 * i]; o.b[8 + i] = a.b[2 * i]; } c.r[rd] = o.r; }
static inline void mmi_ppach(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[i] = b.h[2 * i]; o.h[4 + i] = a.h[2 * i]; } c.r[rd] = o.r; }

// PCPYH: o halfword 0 de cada doubleword se repete; PEXCW/PEXEW trocam palavras.
static inline void mmi_pcpyh(Ctx& c, int rd, int rt) { V128 b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[i] = b.h[0]; o.h[4 + i] = b.h[4]; } c.r[rd] = o.r; }
static inline void mmi_pexcw(Ctx& c, int rd, int rt) { V128 b = V(c.r[rt]), o; o.w[0] = b.w[0]; o.w[1] = b.w[2]; o.w[2] = b.w[1]; o.w[3] = b.w[3]; c.r[rd] = o.r; }
static inline void mmi_pexew(Ctx& c, int rd, int rt) { V128 b = V(c.r[rt]), o; o.w[0] = b.w[2]; o.w[1] = b.w[1]; o.w[2] = b.w[0]; o.w[3] = b.w[3]; c.r[rd] = o.r; }

// PMFHI/PMFLO juntam HI/HI1 e LO/LO1 em um registrador de 128 bits.
static inline void mmi_pmfhi(Ctx& c, int rd) { Reg128 o = { c.hi, c.hi1 }; c.r[rd] = o; }
static inline void mmi_pmflo(Ctx& c, int rd) { Reg128 o = { c.lo, c.lo1 }; c.r[rd] = o; }

// MADD: (HI, LO) += rs * rt, com sinal; o EE tambem grava LO em rd.
static inline void ee_madd(Ctx& c, int rd, int rs, int rt)
{
    int64_t acc = (int64_t)(((uint64_t)(uint32_t)c.hi << 32) | (uint32_t)c.lo);
    acc += (int64_t)(int32_t)c.r[rs].lo * (int64_t)(int32_t)c.r[rt].lo;
    c.lo = S32((uint32_t)acc);
    c.hi = S32((uint32_t)((uint64_t)acc >> 32));
    if (rd != 0) c.r[rd].lo = c.lo;
}

// Pontos de entrada do runtime (a implementar).
void ps2_call(Ctx& c, uint32_t target);
void ps2_syscall(Ctx& c);
void ps2_break(Ctx& c, uint32_t address);
void ps2_ei(Ctx& c);
void ps2_di(Ctx& c);
uint32_t ps2_mfc0(Ctx& c, int reg);
void ps2_mtc0(Ctx& c, int reg, uint32_t value);
void ps2_unsupported(Ctx& c, uint32_t address, const char* mnemonic);
