#include "ps2rt.h"

void f_00200000_switch4(Ctx& c)
{
    // 0x00200000  SLTIU $at, $a0, 4
    c.r[1].lo = (c.r[4].lo < (uint64_t)(4LL)) ? 1 : 0;
    // 0x00200004  BEQ $at, $zero, 0x00200054
    {
        bool take = c.r[1].lo == c.r[0].lo;
        // 0x00200008  SLL $v0, $a0, 2
        c.r[2].lo = S32((uint32_t)c.r[4].lo << 2);
        if (take) goto L_00200054;
    }
    // 0x0020000C  LUI $at, 0x0020
    c.r[1].lo = S32(0x00200000u);
    // 0x00200010  ADDU $at, $at, $v0
    c.r[1].lo = S32((uint32_t)c.r[1].lo + (uint32_t)c.r[2].lo);
    // 0x00200014  LW $v0, 256($at)
    c.r[2].lo = S32(mrd<uint32_t>(c, (uint32_t)c.r[1].lo + 0x100u));
    // 0x00200018  NOP
    // 0x0020001C  JR $v0
    {
        uint32_t dest = (uint32_t)c.r[2].lo;
        // 0x00200020  NOP
        // jump table em 0x00200100, 4 destinos
        switch (dest)
        {
            case 0x00200024u: goto L_00200024;
            case 0x00200030u: goto L_00200030;
            case 0x0020003Cu: goto L_0020003C;
            case 0x00200048u: goto L_00200048;
            default: ps2_unsupported(c, 0x0020001Cu, "JR"); return;
        }
    }
L_00200024:
    // 0x00200024  ADDIU $v0, $zero, 0xA
    c.r[2].lo = S32((uint32_t)c.r[0].lo + 0xAu);
    // 0x00200028  JR $ra
    {
        // 0x0020002C  NOP
        return;
    }
L_00200030:
    // 0x00200030  ADDIU $v0, $zero, 0x14
    c.r[2].lo = S32((uint32_t)c.r[0].lo + 0x14u);
    // 0x00200034  JR $ra
    {
        // 0x00200038  NOP
        return;
    }
L_0020003C:
    // 0x0020003C  ADDIU $v0, $zero, 0x1E
    c.r[2].lo = S32((uint32_t)c.r[0].lo + 0x1Eu);
    // 0x00200040  JR $ra
    {
        // 0x00200044  NOP
        return;
    }
L_00200048:
    // 0x00200048  ADDIU $v0, $zero, 0x28
    c.r[2].lo = S32((uint32_t)c.r[0].lo + 0x28u);
    // 0x0020004C  JR $ra
    {
        // 0x00200050  NOP
        return;
    }
L_00200054:
    // 0x00200054  ADDIU $v0, $zero, -0x1
    c.r[2].lo = S32((uint32_t)c.r[0].lo + 0xFFFFFFFFu);
    // 0x00200058  JR $ra
    {
        // 0x0020005C  NOP
        return;
    }
}
