#include "ps2_functions.h"
#include <cstdio>
#include <cstdlib>

typedef void (*Ps2Func)(Ctx&);

static Ps2Func lookup(uint32_t address)
{
    unsigned lo = 0;
    unsigned hi = ps2_function_count;

    while (lo < hi)
    {
        unsigned mid = (lo + hi) / 2;
        uint32_t a = ps2_function_table[mid].address;

        if (a == address) return ps2_function_table[mid].fn;
        if (a < address) lo = mid + 1; else hi = mid;
    }

    return nullptr;
}

void ps2_call(Ctx& c, uint32_t target)
{
    Ps2Func fn = lookup(target);

    if (!fn)
    {
        std::fprintf(stderr, "ps2_call: 0x%08X nao e inicio de funcao conhecida\n", target);
        std::abort();
    }

    fn(c);
}

// JR indireto: o destino precisa ser o inicio de uma funcao (tail call).
void ps2_tailcall(Ctx& c, uint32_t target)
{
    Ps2Func fn = lookup(target);

    if (!fn)
    {
        std::fprintf(stderr, "salto indireto para 0x%08X, que nao e inicio de funcao (longjmp ou catch?)\n", target);
        std::abort();
    }

    fn(c);
}

void ps2_syscall(Ctx& c)
{
    std::fprintf(stderr, "syscall %d ainda nao implementada\n", (int)(int16_t)c.r[3].lo);
    std::abort();
}

void ps2_break(Ctx&, uint32_t address)
{
    std::fprintf(stderr, "BREAK em 0x%08X\n", address);
    std::abort();
}

void ps2_unsupported(Ctx&, uint32_t address, const char* mnemonic)
{
    std::fprintf(stderr, "instrucao sem suporte em 0x%08X (%s)\n", address, mnemonic);
    std::abort();
}

void ps2_ei(Ctx&) {}
void ps2_di(Ctx&) {}
uint32_t ps2_mfc0(Ctx&, int) { return 0; }
void ps2_mtc0(Ctx&, int, uint32_t) {}
