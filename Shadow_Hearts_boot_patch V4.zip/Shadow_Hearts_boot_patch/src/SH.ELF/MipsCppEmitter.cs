using System.Text;
using System.Text.RegularExpressions;

namespace SH.ELF;

// Gerador de C++ a partir de uma funcao MIPS (R5900), um subconjunto por vez.
// Instrucoes ainda sem suporte viram chamadas a ps2_unsupported(...), e sao
// contadas no resultado. O texto gerado e so ASCII (compila em MSVC e GCC).
public static class MipsCppEmitter
{
    public sealed record Result(
        string Code,
        int Instructions,
        int Unsupported,
        IReadOnlyDictionary<string, int> UnsupportedByMnemonic,
        int RuntimeDispatches);

    // Runtime minimo que o codigo gerado espera. Sem aspas duplas aqui dentro.
    public const string RuntimeHeader = @"#pragma once
#include <cstdint>
#include <cstring>
#include <cmath>

// Registrador de 128 bits do EE. As operacoes de 64 bits usam so o lo.
struct Reg128 { uint64_t lo; uint64_t hi; };

struct Ctx
{
    Reg128 r[32];     // r[0] nunca e escrito: o codigo gerado pula escritas em $zero
    uint64_t hi, lo;  // HI/LO (pipeline 0)
    uint64_t hi1, lo1;  // HI1/LO1 (pipeline 1)
    uint32_t sa;      // registrador SA (QFSRV): deslocamento em bits
    uint32_t f[32];   // registradores da FPU, como bits de float
    uint32_t acc;     // acumulador da FPU
    uint32_t fcr31;   // controle da FPU: bit 23 = condicao (C)
    uint32_t vf[32][4];  // VU0: registradores VF (x, y, z, w) como bits de float
    uint32_t vacc[4];    // VU0: acumulador
    uint32_t vi[32];     // VU0: VI0..VI15 (16 bits) e controle: 16 status, 17 MAC, 18 clip, 20 R, 21 I, 22 Q, 23 P, 27 CMSAR0
    uint8_t* mem;     // RAM do EE (32 MB) no host
    uint8_t* spr;     // scratchpad do EE (16 KB) no host
};

static inline uint64_t S32(uint32_t v) { return (uint64_t)(int64_t)(int32_t)v; }

// Diagnostico: compile com -DPS2_TRACE para guardar as ultimas funcoes entradas.
#ifdef PS2_TRACE
void ps2_trace_enter(uint32_t address);
#define PS2_TRACE_ENTER(a) ps2_trace_enter(a)
#else
#define PS2_TRACE_ENTER(a) ((void)0)
#endif

// ---- memoria do EE ----
// 0..1FFFFFFF e kseg0/kseg1 (80000000..BFFFFFFF) sao a RAM de 32 MB; 2xxxxxxx e 3xxxxxxx
// tambem espelham a RAM; 10000000..1FFFFFFF e hardware (tratado pelo runtime);
// 70000000 e o scratchpad de 16 KB. Qualquer outro endereco e erro.

uint64_t ps2_hw_read(Ctx& c, uint32_t phys, int size);
void ps2_hw_write(Ctx& c, uint32_t phys, uint64_t value, int size);
[[noreturn]] void ps2_bad_address(Ctx& c, uint32_t address, int write);

static inline uint32_t ee_phys(uint32_t a)
{
    switch (a >> 28)
    {
        case 0x8: case 0x9: case 0xA: case 0xB: return a & 0x1FFFFFFFu;   // kseg0 e kseg1
        case 0x2: case 0x3: return a & 0x0FFFFFFFu;
        default: return a;
    }
}

// Acesso a hardware: ate 8 bytes e uma chamada; 128 bits sao duas de 64.
// Feito com especializacao de template para compilar em C++11.
template <class T, bool Small = (sizeof(T) <= 8)> struct HwAccess;

template <class T> struct HwAccess<T, true>
{
    static T read(Ctx& c, uint32_t p)
    {
        T v;
        uint64_t x = ps2_hw_read(c, p, (int)sizeof(T));
        std::memcpy(&v, &x, sizeof(T));
        return v;
    }

    static void write(Ctx& c, uint32_t p, T v)
    {
        uint64_t x = 0;
        std::memcpy(&x, &v, sizeof(T));
        ps2_hw_write(c, p, x, (int)sizeof(T));
    }
};

template <class T> struct HwAccess<T, false>
{
    static T read(Ctx& c, uint32_t p)
    {
        T v;
        uint64_t lo = ps2_hw_read(c, p, 8);
        uint64_t hi = ps2_hw_read(c, p + 8, 8);
        std::memcpy(&v, &lo, 8);
        std::memcpy(reinterpret_cast<uint8_t*>(&v) + 8, &hi, 8);
        return v;
    }

    static void write(Ctx& c, uint32_t p, T v)
    {
        uint64_t lo, hi;
        std::memcpy(&lo, &v, 8);
        std::memcpy(&hi, reinterpret_cast<const uint8_t*>(&v) + 8, 8);
        ps2_hw_write(c, p, lo, 8);
        ps2_hw_write(c, p + 8, hi, 8);
    }
};

template <class T> static inline T mrd(Ctx& c, uint32_t addr)
{
    if ((addr >> 28) == 7)
    {
        T v;
        std::memcpy(&v, c.spr + (addr & 0x3FFFu), sizeof(T));
        return v;
    }

    uint32_t p = ee_phys(addr);

    if (p < 0x02000000u)
    {
        T v;
        std::memcpy(&v, c.mem + p, sizeof(T));
        return v;
    }

    if (p >= 0x10000000u && p < 0x20000000u)
        return HwAccess<T>::read(c, p);

    ps2_bad_address(c, addr, 0);
}

template <class T> static inline void mwr(Ctx& c, uint32_t addr, T v)
{
    if ((addr >> 28) == 7)
    {
        std::memcpy(c.spr + (addr & 0x3FFFu), &v, sizeof(T));
        return;
    }

    uint32_t p = ee_phys(addr);

    if (p < 0x02000000u)
    {
        std::memcpy(c.mem + p, &v, sizeof(T));
        return;
    }

    if (p >= 0x10000000u && p < 0x20000000u)
    {
        HwAccess<T>::write(c, p, v);
        return;
    }

    ps2_bad_address(c, addr, 1);
}

// ---- multiplicacao e divisao inteira (EE: MULT/MULTU tambem gravam rd) ----
// As variantes 1 usam o segundo par HI1/LO1 (pipeline 1).

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_mult_t(Ctx& c, int rd, int rs, int rt)
{
    int64_t p = (int64_t)(int32_t)c.r[rs].lo * (int64_t)(int32_t)c.r[rt].lo;
    c.*LO = S32((uint32_t)p);
    c.*HI = S32((uint32_t)((uint64_t)p >> 32));
    if (rd != 0) c.r[rd].lo = c.*LO;
}

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_multu_t(Ctx& c, int rd, int rs, int rt)
{
    uint64_t p = (uint64_t)(uint32_t)c.r[rs].lo * (uint64_t)(uint32_t)c.r[rt].lo;
    c.*LO = S32((uint32_t)p);
    c.*HI = S32((uint32_t)(p >> 32));
    if (rd != 0) c.r[rd].lo = c.*LO;
}

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_div_t(Ctx& c, int rs, int rt)
{
    int32_t a = (int32_t)c.r[rs].lo;
    int32_t b = (int32_t)c.r[rt].lo;
    if (b == 0)
    {
        c.*LO = S32(a >= 0 ? 0xFFFFFFFFu : 1u);
        c.*HI = S32((uint32_t)a);
    }
    else if (a == INT32_MIN && b == -1)
    {
        c.*LO = S32(0x80000000u);
        c.*HI = 0;
    }
    else
    {
        c.*LO = S32((uint32_t)(a / b));
        c.*HI = S32((uint32_t)(a % b));
    }
}

template <uint64_t Ctx::*HI, uint64_t Ctx::*LO>
static inline void ee_divu_t(Ctx& c, int rs, int rt)
{
    uint32_t a = (uint32_t)c.r[rs].lo;
    uint32_t b = (uint32_t)c.r[rt].lo;
    if (b == 0)
    {
        c.*LO = S32(0xFFFFFFFFu);
        c.*HI = S32(a);
    }
    else
    {
        c.*LO = S32(a / b);
        c.*HI = S32(a % b);
    }
}

static inline void ee_mult(Ctx& c, int rd, int rs, int rt)   { ee_mult_t<&Ctx::hi, &Ctx::lo>(c, rd, rs, rt); }
static inline void ee_multu(Ctx& c, int rd, int rs, int rt)  { ee_multu_t<&Ctx::hi, &Ctx::lo>(c, rd, rs, rt); }
static inline void ee_div(Ctx& c, int rs, int rt)            { ee_div_t<&Ctx::hi, &Ctx::lo>(c, rs, rt); }
static inline void ee_divu(Ctx& c, int rs, int rt)           { ee_divu_t<&Ctx::hi, &Ctx::lo>(c, rs, rt); }
static inline void ee_mult1(Ctx& c, int rd, int rs, int rt)  { ee_mult_t<&Ctx::hi1, &Ctx::lo1>(c, rd, rs, rt); }
static inline void ee_multu1(Ctx& c, int rd, int rs, int rt) { ee_multu_t<&Ctx::hi1, &Ctx::lo1>(c, rd, rs, rt); }
static inline void ee_div1(Ctx& c, int rs, int rt)           { ee_div_t<&Ctx::hi1, &Ctx::lo1>(c, rs, rt); }
static inline void ee_divu1(Ctx& c, int rs, int rt)          { ee_divu_t<&Ctx::hi1, &Ctx::lo1>(c, rs, rt); }

// ---- cargas e gravacoes desalinhadas (little-endian) ----

static inline void ee_lwl(Ctx& c, int rt, uint32_t addr)
{
    uint32_t w = mrd<uint32_t>(c, addr & ~3u);
    uint32_t s = addr & 3u;
    uint32_t r = ((uint32_t)c.r[rt].lo & (0x00FFFFFFu >> (8 * s))) | (w << (24 - 8 * s));
    c.r[rt].lo = S32(r);
}

static inline void ee_lwr(Ctx& c, int rt, uint32_t addr)
{
    uint32_t w = mrd<uint32_t>(c, addr & ~3u);
    uint32_t s = addr & 3u;
    uint32_t r = ((uint32_t)c.r[rt].lo & (0xFFFFFF00u << (24 - 8 * s))) | (w >> (8 * s));
    if (s == 0) c.r[rt].lo = S32(r);
    else c.r[rt].lo = (c.r[rt].lo & 0xFFFFFFFF00000000ull) | r;
}

static inline void ee_swl(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~3u;
    uint32_t s = addr & 3u;
    uint32_t w = mrd<uint32_t>(c, a);
    w = (w & (0xFFFFFF00u << (8 * s))) | ((uint32_t)c.r[rt].lo >> (24 - 8 * s));
    mwr<uint32_t>(c, a, w);
}

static inline void ee_swr(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~3u;
    uint32_t s = addr & 3u;
    uint32_t w = mrd<uint32_t>(c, a);
    w = (w & (0x00FFFFFFu >> (24 - 8 * s))) | ((uint32_t)c.r[rt].lo << (8 * s));
    mwr<uint32_t>(c, a, w);
}

static inline void ee_ldl(Ctx& c, int rt, uint32_t addr)
{
    uint64_t d = mrd<uint64_t>(c, addr & ~7u);
    uint32_t s = addr & 7u;
    c.r[rt].lo = (c.r[rt].lo & (0x00FFFFFFFFFFFFFFull >> (8 * s))) | (d << (56 - 8 * s));
}

static inline void ee_ldr(Ctx& c, int rt, uint32_t addr)
{
    uint64_t d = mrd<uint64_t>(c, addr & ~7u);
    uint32_t s = addr & 7u;
    c.r[rt].lo = (c.r[rt].lo & (0xFFFFFFFFFFFFFF00ull << (56 - 8 * s))) | (d >> (8 * s));
}

static inline void ee_sdl(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~7u;
    uint32_t s = addr & 7u;
    uint64_t d = mrd<uint64_t>(c, a);
    d = (d & (0xFFFFFFFFFFFFFF00ull << (8 * s))) | (c.r[rt].lo >> (56 - 8 * s));
    mwr<uint64_t>(c, a, d);
}

static inline void ee_sdr(Ctx& c, int rt, uint32_t addr)
{
    uint32_t a = addr & ~7u;
    uint32_t s = addr & 7u;
    uint64_t d = mrd<uint64_t>(c, a);
    d = (d & (0x00FFFFFFFFFFFFFFull >> (56 - 8 * s))) | (c.r[rt].lo << (8 * s));
    mwr<uint64_t>(c, a, d);
}

// ---- FPU do EE: so precisao simples, sem NaN/Inf/denormais ----
// Entradas Inf/NaN viram +-FLT_MAX e denormais viram +-0. Resultados saturam em
// +-FLT_MAX e sao truncados em direcao a zero. Flags de excecao ainda ignoradas.

static inline float f32(uint32_t b) { float v; std::memcpy(&v, &b, 4); return v; }
static inline uint32_t u32(float v) { uint32_t b; std::memcpy(&b, &v, 4); return b; }

static inline double ee_in(uint32_t b)
{
    uint32_t e = b & 0x7F800000u;
    if (e == 0) return (b & 0x80000000u) ? -0.0 : 0.0;
    if (e == 0x7F800000u) b = (b & 0x80000000u) | 0x7F7FFFFFu;
    return (double)f32(b);
}

static inline uint32_t ee_pack(double v)
{
    const double MAXF = 3.4028234663852886e+38;
    if (v != v) v = 0.0;
    if (v > MAXF) v = MAXF;
    else if (v < -MAXF) v = -MAXF;

    float r = (float)v;
    if (std::fabs((double)r) > std::fabs(v))
        r = std::nextafterf(r, 0.0f);

    uint32_t b = u32(r);
    if ((b & 0x7F800000u) == 0) b &= 0x80000000u;
    return b;
}

static inline void fpu_set_c(Ctx& c, bool v)
{
    if (v) c.fcr31 |= 0x00800000u; else c.fcr31 &= ~0x00800000u;
}

static inline void fpu_add(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.f[fs]) + ee_in(c.f[ft])); }
static inline void fpu_sub(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.f[fs]) - ee_in(c.f[ft])); }
static inline void fpu_mul(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.f[fs]) * ee_in(c.f[ft])); }

static inline void fpu_div(Ctx& c, int fd, int fs, int ft)
{
    double d = ee_in(c.f[ft]);
    if (d == 0.0) { c.f[fd] = ((c.f[fs] ^ c.f[ft]) & 0x80000000u) | 0x7F7FFFFFu; return; }
    c.f[fd] = ee_pack(ee_in(c.f[fs]) / d);
}

static inline void fpu_sqrt(Ctx& c, int fd, int ft)
{
    c.f[fd] = ee_pack(std::sqrt(std::fabs(ee_in(c.f[ft]))));
}

static inline void fpu_rsqrt(Ctx& c, int fd, int fs, int ft)
{
    double d = std::sqrt(std::fabs(ee_in(c.f[ft])));
    if (d == 0.0) { c.f[fd] = (c.f[fs] & 0x80000000u) | 0x7F7FFFFFu; return; }
    c.f[fd] = ee_pack(ee_in(c.f[fs]) / d);
}

static inline void fpu_max(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_in(c.f[fs]) > ee_in(c.f[ft]) ? c.f[fs] : c.f[ft]; }
static inline void fpu_min(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_in(c.f[fs]) < ee_in(c.f[ft]) ? c.f[fs] : c.f[ft]; }

static inline void fpu_adda(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.f[fs]) + ee_in(c.f[ft])); }
static inline void fpu_suba(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.f[fs]) - ee_in(c.f[ft])); }
static inline void fpu_mula(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_madd(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.acc) + ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_msub(Ctx& c, int fd, int fs, int ft) { c.f[fd] = ee_pack(ee_in(c.acc) - ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_madda(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.acc) + ee_in(c.f[fs]) * ee_in(c.f[ft])); }
static inline void fpu_msuba(Ctx& c, int fs, int ft) { c.acc = ee_pack(ee_in(c.acc) - ee_in(c.f[fs]) * ee_in(c.f[ft])); }

static inline void fpu_cvt_s_w(Ctx& c, int fd, int fs) { c.f[fd] = ee_pack((double)(int32_t)c.f[fs]); }

static inline void fpu_cvt_w_s(Ctx& c, int fd, int fs)
{
    double v = ee_in(c.f[fs]);
    if (v >= 2147483648.0) c.f[fd] = 0x7FFFFFFFu;
    else if (v <= -2147483648.0) c.f[fd] = 0x80000000u;
    else c.f[fd] = (uint32_t)(int32_t)v;
}

static inline void fpu_c_eq(Ctx& c, int fs, int ft) { fpu_set_c(c, ee_in(c.f[fs]) == ee_in(c.f[ft])); }
static inline void fpu_c_lt(Ctx& c, int fs, int ft) { fpu_set_c(c, ee_in(c.f[fs]) < ee_in(c.f[ft])); }
static inline void fpu_c_le(Ctx& c, int fs, int ft) { fpu_set_c(c, ee_in(c.f[fs]) <= ee_in(c.f[ft])); }

// ---- VU0 em modo macro (COP2) ----
// Chame vu0_init(c) uma vez no inicio: VF0 e sempre (0, 0, 0, 1).
// Flags MAC e status ainda nao sao calculadas; o clip (VCLIPw) e exato.
// As variaveis Q, I e P ficam em vi[22], vi[21] e vi[23].

enum { VU_ADD, VU_SUB, VU_MUL, VU_MADD, VU_MSUB, VU_MAX, VU_MIN };
enum { VU_SRC_VEC, VU_SRC_X, VU_SRC_Y, VU_SRC_Z, VU_SRC_W, VU_SRC_Q, VU_SRC_I };

static inline void vu0_init(Ctx& c)
{
    c.vf[0][0] = 0; c.vf[0][1] = 0; c.vf[0][2] = 0; c.vf[0][3] = 0x3F800000u;
}

static inline Reg128 vu_qmfc2(Ctx& c, int vf)
{
    Reg128 r;
    std::memcpy(&r, c.vf[vf], 16);
    return r;
}

static inline void vu_qmtc2(Ctx& c, int vf, Reg128 r)
{
    if (vf != 0) std::memcpy(c.vf[vf], &r, 16);
}

static inline uint32_t vu_cfc2(Ctx& c, int r)
{
    if (r == 0) return 0;
    if (r < 16) return c.vi[r] & 0xFFFFu;
    return c.vi[r & 31];
}

static inline void vu_ctc2(Ctx& c, int r, uint32_t v)
{
    if (r == 0) return;
    if (r < 16) c.vi[r] = v & 0xFFFFu;
    else if (r == 18) c.vi[18] = v & 0xFFFFFFu;
    else c.vi[r & 31] = v;
}

// Aritmetica por faixa: fd = fs OP fonte. Com to_acc, grava no acumulador.
// MADD/MSUB usam o acumulador como parcela. So as faixas de dest (x=8 .. w=1) mudam.
static inline void vu_arith(Ctx& c, int op, int src, int dest, int fd, int fs, int ft, int to_acc)
{
    uint32_t res[4];
    for (int l = 0; l < 4; l++)
    {
        uint32_t a = c.vf[fs][l];
        uint32_t b;
        switch (src)
        {
            case VU_SRC_VEC: b = c.vf[ft][l]; break;
            case VU_SRC_X:   b = c.vf[ft][0]; break;
            case VU_SRC_Y:   b = c.vf[ft][1]; break;
            case VU_SRC_Z:   b = c.vf[ft][2]; break;
            case VU_SRC_W:   b = c.vf[ft][3]; break;
            case VU_SRC_Q:   b = c.vi[22]; break;
            default:         b = c.vi[21]; break;
        }
        switch (op)
        {
            case VU_ADD:  res[l] = ee_pack(ee_in(a) + ee_in(b)); break;
            case VU_SUB:  res[l] = ee_pack(ee_in(a) - ee_in(b)); break;
            case VU_MUL:  res[l] = ee_pack(ee_in(a) * ee_in(b)); break;
            case VU_MADD: res[l] = ee_pack(ee_in(c.vacc[l]) + ee_in(a) * ee_in(b)); break;
            case VU_MSUB: res[l] = ee_pack(ee_in(c.vacc[l]) - ee_in(a) * ee_in(b)); break;
            case VU_MAX:  res[l] = ee_in(a) > ee_in(b) ? a : b; break;
            default:      res[l] = ee_in(a) < ee_in(b) ? a : b; break;
        }
    }
    for (int l = 0; l < 4; l++)
    {
        if (!(dest & (8 >> l))) continue;
        if (to_acc) c.vacc[l] = res[l];
        else if (fd != 0) c.vf[fd][l] = res[l];
    }
}

// Produto vetorial: OPMULA grava no acumulador, OPMSUB subtrai dele (so xyz).
static inline void vu_opmula(Ctx& c, int fs, int ft)
{
    uint32_t x = ee_pack(ee_in(c.vf[fs][1]) * ee_in(c.vf[ft][2]));
    uint32_t y = ee_pack(ee_in(c.vf[fs][2]) * ee_in(c.vf[ft][0]));
    uint32_t z = ee_pack(ee_in(c.vf[fs][0]) * ee_in(c.vf[ft][1]));
    c.vacc[0] = x; c.vacc[1] = y; c.vacc[2] = z;
}

static inline void vu_opmsub(Ctx& c, int fd, int fs, int ft)
{
    uint32_t x = ee_pack(ee_in(c.vacc[0]) - ee_in(c.vf[fs][1]) * ee_in(c.vf[ft][2]));
    uint32_t y = ee_pack(ee_in(c.vacc[1]) - ee_in(c.vf[fs][2]) * ee_in(c.vf[ft][0]));
    uint32_t z = ee_pack(ee_in(c.vacc[2]) - ee_in(c.vf[fs][0]) * ee_in(c.vf[ft][1]));
    if (fd != 0) { c.vf[fd][0] = x; c.vf[fd][1] = y; c.vf[fd][2] = z; }
}

static inline void vu_move(Ctx& c, int dest, int ft, int fs)
{
    uint32_t t[4] = { c.vf[fs][0], c.vf[fs][1], c.vf[fs][2], c.vf[fs][3] };
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

static inline void vu_mr32(Ctx& c, int dest, int ft, int fs)
{
    uint32_t t[4] = { c.vf[fs][1], c.vf[fs][2], c.vf[fs][3], c.vf[fs][0] };
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

static inline void vu_abs(Ctx& c, int dest, int ft, int fs)
{
    uint32_t t[4] = { c.vf[fs][0], c.vf[fs][1], c.vf[fs][2], c.vf[fs][3] };
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l] & 0x7FFFFFFFu;
}

// Inteiro para float com n bits fracionarios (n = 0, 4, 12, 15), e o inverso (trunca e satura).
static inline void vu_itof(Ctx& c, int dest, int ft, int fs, int n)
{
    uint32_t t[4];
    for (int l = 0; l < 4; l++) t[l] = ee_pack((double)(int32_t)c.vf[fs][l] / (double)(1 << n));
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

static inline void vu_ftoi(Ctx& c, int dest, int ft, int fs, int n)
{
    uint32_t t[4];
    for (int l = 0; l < 4; l++)
    {
        double v = ee_in(c.vf[fs][l]) * (double)(1 << n);
        if (v >= 2147483648.0) t[l] = 0x7FFFFFFFu;
        else if (v <= -2147483648.0) t[l] = 0x80000000u;
        else t[l] = (uint32_t)(int32_t)v;
    }
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = t[l];
}

// VCLIPw: compara fs.xyz com |ft.w| e empilha 6 bits no historico de clip (24 bits).
static inline void vu_clipw(Ctx& c, int fs, int ft)
{
    double w = std::fabs(ee_in(c.vf[ft][3]));
    double x = ee_in(c.vf[fs][0]);
    double y = ee_in(c.vf[fs][1]);
    double z = ee_in(c.vf[fs][2]);
    uint32_t clip = (c.vi[18] << 6) & 0xFFFFFFu;
    if (x > w) clip |= 0x01u;
    if (x < -w) clip |= 0x02u;
    if (y > w) clip |= 0x04u;
    if (y < -w) clip |= 0x08u;
    if (z > w) clip |= 0x10u;
    if (z < -w) clip |= 0x20u;
    c.vi[18] = clip;
}

// Q = fs.fsf / ft.ftf. Divisor zero satura em +-FLT_MAX com o sinal do xor.
static inline void vu_div(Ctx& c, int fs, int fsf, int ft, int ftf)
{
    uint32_t a = c.vf[fs][fsf];
    uint32_t b = c.vf[ft][ftf];
    double d = ee_in(b);
    if (d == 0.0) c.vi[22] = ((a ^ b) & 0x80000000u) | 0x7F7FFFFFu;
    else c.vi[22] = ee_pack(ee_in(a) / d);
}

static inline void vu_sqrt(Ctx& c, int ft, int ftf)
{
    c.vi[22] = ee_pack(std::sqrt(std::fabs(ee_in(c.vf[ft][ftf]))));
}

static inline void vu_rsqrt(Ctx& c, int fs, int fsf, int ft, int ftf)
{
    uint32_t a = c.vf[fs][fsf];
    uint32_t b = c.vf[ft][ftf];
    double d = std::sqrt(std::fabs(ee_in(b)));
    if (d == 0.0) c.vi[22] = ((a ^ b) & 0x80000000u) | 0x7F7FFFFFu;
    else c.vi[22] = ee_pack(ee_in(a) / d);
}

// Inteiros do VU0 (16 bits; VI0 e sempre 0).
static inline void vu_vi_set(Ctx& c, int r, uint32_t v) { if (r != 0) c.vi[r] = v & 0xFFFFu; }
static inline void vu_iadd(Ctx& c, int id, int is, int it) { vu_vi_set(c, id, c.vi[is] + c.vi[it]); }
static inline void vu_isub(Ctx& c, int id, int is, int it) { vu_vi_set(c, id, c.vi[is] - c.vi[it]); }
static inline void vu_iand(Ctx& c, int id, int is, int it) { vu_vi_set(c, id, c.vi[is] & c.vi[it]); }
static inline void vu_ior(Ctx& c, int id, int is, int it)  { vu_vi_set(c, id, c.vi[is] | c.vi[it]); }
static inline void vu_iaddi(Ctx& c, int it, int is, int imm5) { vu_vi_set(c, it, c.vi[is] + (uint32_t)imm5); }
static inline void vu_mtir(Ctx& c, int it, int fs, int fsf) { vu_vi_set(c, it, c.vf[fs][fsf]); }

static inline void vu_mfir(Ctx& c, int dest, int ft, int is)
{
    uint32_t v = (uint32_t)(int32_t)(int16_t)c.vi[is];
    for (int l = 0; l < 4; l++) if (ft != 0 && (dest & (8 >> l))) c.vf[ft][l] = v;
}

// ---- MMI: operacoes paralelas sobre os 128 bits ----

union V128 { Reg128 r; uint8_t b[16]; uint16_t h[8]; uint32_t w[4]; uint64_t d[2]; };

static inline V128 V(const Reg128& r) { V128 v; v.r = r; return v; }

static inline void mmi_pand(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rs].lo & c.r[rt].lo, c.r[rs].hi & c.r[rt].hi }; c.r[rd] = o; }
static inline void mmi_por(Ctx& c, int rd, int rs, int rt)  { Reg128 o = { c.r[rs].lo | c.r[rt].lo, c.r[rs].hi | c.r[rt].hi }; c.r[rd] = o; }
static inline void mmi_pxor(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rs].lo ^ c.r[rt].lo, c.r[rs].hi ^ c.r[rt].hi }; c.r[rd] = o; }
static inline void mmi_pnor(Ctx& c, int rd, int rs, int rt) { Reg128 o = { ~(c.r[rs].lo | c.r[rt].lo), ~(c.r[rs].hi | c.r[rt].hi) }; c.r[rd] = o; }

static inline void mmi_pcpyld(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rt].lo, c.r[rs].lo }; c.r[rd] = o; }
static inline void mmi_pcpyud(Ctx& c, int rd, int rs, int rt) { Reg128 o = { c.r[rs].hi, c.r[rt].hi }; c.r[rd] = o; }

static inline void mmi_paddw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] + b.w[i]; c.r[rd] = o.r; }
static inline void mmi_psubw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] - b.w[i]; c.r[rd] = o.r; }
static inline void mmi_paddh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] + b.h[i]); c.r[rd] = o.r; }
static inline void mmi_psubh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] - b.h[i]); c.r[rd] = o.r; }
static inline void mmi_paddb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 16; i++) o.b[i] = (uint8_t)(a.b[i] + b.b[i]); c.r[rd] = o.r; }
static inline void mmi_psubb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 16; i++) o.b[i] = (uint8_t)(a.b[i] - b.b[i]); c.r[rd] = o.r; }

// PADDUB: soma de bytes sem sinal com saturacao em 255 (com rt = $zero e uma copia de 128 bits).
static inline void mmi_paddub(Ctx& c, int rd, int rs, int rt)
{
    V128 a = V(c.r[rs]), b = V(c.r[rt]), o;
    for (int i = 0; i < 16; i++) { unsigned v = (unsigned)a.b[i] + b.b[i]; o.b[i] = (uint8_t)(v > 255u ? 255u : v); }
    c.r[rd] = o.r;
}

// Deslocamentos por constante (rd, rt, sa).
static inline void mmi_psllh(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] << (sa & 15)); c.r[rd] = o.r; }
static inline void mmi_psrlh(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)(a.h[i] >> (sa & 15)); c.r[rd] = o.r; }
static inline void mmi_psrah(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (uint16_t)((int16_t)a.h[i] >> (sa & 15)); c.r[rd] = o.r; }
static inline void mmi_psllw(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] << (sa & 31); c.r[rd] = o.r; }
static inline void mmi_psrlw(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = a.w[i] >> (sa & 31); c.r[rd] = o.r; }
static inline void mmi_psraw(Ctx& c, int rd, int rt, int sa) { V128 a = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = (uint32_t)((int32_t)a.w[i] >> (sa & 31)); c.r[rd] = o.r; }

// Intercalacao: rt fica nas posicoes pares e rs nas impares.
static inline void mmi_pextlb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { o.b[2 * i] = b.b[i];     o.b[2 * i + 1] = a.b[i]; }     c.r[rd] = o.r; }
static inline void mmi_pextub(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { o.b[2 * i] = b.b[8 + i]; o.b[2 * i + 1] = a.b[8 + i]; } c.r[rd] = o.r; }
static inline void mmi_pextlh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[2 * i] = b.h[i];     o.h[2 * i + 1] = a.h[i]; }     c.r[rd] = o.r; }
static inline void mmi_pextuh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[2 * i] = b.h[4 + i]; o.h[2 * i + 1] = a.h[4 + i]; } c.r[rd] = o.r; }
static inline void mmi_pextlw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 2; i++) { o.w[2 * i] = b.w[i];     o.w[2 * i + 1] = a.w[i]; }     c.r[rd] = o.r; }
static inline void mmi_pextuw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 2; i++) { o.w[2 * i] = b.w[2 + i]; o.w[2 * i + 1] = a.w[2 + i]; } c.r[rd] = o.r; }

// QFSRV: ({rs, rt} >> SA)[127:0]. SA vem de MTSAB/MTSAH.
static inline Reg128 shr128(Reg128 v, unsigned n)
{
    if (n == 0) return v;
    Reg128 o;
    if (n < 64) { o.lo = (v.lo >> n) | (v.hi << (64 - n)); o.hi = v.hi >> n; }
    else        { o.lo = v.hi >> (n - 64); o.hi = 0; }
    return o;
}

static inline Reg128 shl128(Reg128 v, unsigned n)
{
    if (n == 0) return v;
    Reg128 o;
    if (n < 64) { o.hi = (v.hi << n) | (v.lo >> (64 - n)); o.lo = v.lo << n; }
    else        { o.hi = v.lo << (n - 64); o.lo = 0; }
    return o;
}

static inline void mmi_qfsrv(Ctx& c, int rd, int rs, int rt)
{
    unsigned sa = c.sa & 127u;
    Reg128 lo = shr128(c.r[rt], sa);
    Reg128 hi = sa == 0 ? Reg128{0, 0} : shl128(c.r[rs], 128 - sa);
    Reg128 o = { lo.lo | hi.lo, lo.hi | hi.hi };
    c.r[rd] = o;
}

static inline void ee_mtsab(Ctx& c, int rs, uint32_t imm) { c.sa = (((uint32_t)c.r[rs].lo & 15u) ^ (imm & 15u)) * 8u; }
static inline void ee_mtsah(Ctx& c, int rs, uint32_t imm) { c.sa = (((uint32_t)c.r[rs].lo & 7u) ^ (imm & 7u)) * 16u; }

// ---- MMI: comparacoes, min/max, pack e trocas ----

static inline void mmi_pcgth(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (int16_t)a.h[i] > (int16_t)b.h[i] ? 0xFFFFu : 0u; c.r[rd] = o.r; }
static inline void mmi_pminh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (int16_t)a.h[i] < (int16_t)b.h[i] ? a.h[i] : b.h[i]; c.r[rd] = o.r; }
static inline void mmi_pmaxh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) o.h[i] = (int16_t)a.h[i] > (int16_t)b.h[i] ? a.h[i] : b.h[i]; c.r[rd] = o.r; }
static inline void mmi_pminw(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) o.w[i] = (int32_t)a.w[i] < (int32_t)b.w[i] ? a.w[i] : b.w[i]; c.r[rd] = o.r; }

// Saturacao sem sinal: PSUBUB fica em 0, PADDUH fica em 0xFFFF.
static inline void mmi_psubub(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 16; i++) o.b[i] = (uint8_t)(a.b[i] > b.b[i] ? a.b[i] - b.b[i] : 0); c.r[rd] = o.r; }
static inline void mmi_padduh(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { unsigned v = (unsigned)a.h[i] + b.h[i]; o.h[i] = (uint16_t)(v > 0xFFFFu ? 0xFFFFu : v); } c.r[rd] = o.r; }

// PPACB/PPACH: pega os elementos pares; rt vai para a metade baixa e rs para a alta.
static inline void mmi_ppacb(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 8; i++) { o.b[i] = b.b[2 * i]; o.b[8 + i] = a.b[2 * i]; } c.r[rd] = o.r; }
static inline void mmi_ppach(Ctx& c, int rd, int rs, int rt) { V128 a = V(c.r[rs]), b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[i] = b.h[2 * i]; o.h[4 + i] = a.h[2 * i]; } c.r[rd] = o.r; }

// PCPYH: o halfword 0 de cada doubleword se repete; PEXCW/PEXEW trocam palavras.
static inline void mmi_pcpyh(Ctx& c, int rd, int rt) { V128 b = V(c.r[rt]), o; for (int i = 0; i < 4; i++) { o.h[i] = b.h[0]; o.h[4 + i] = b.h[4]; } c.r[rd] = o.r; }
static inline void mmi_pexcw(Ctx& c, int rd, int rt) { V128 b = V(c.r[rt]), o; o.w[0] = b.w[0]; o.w[1] = b.w[2]; o.w[2] = b.w[1]; o.w[3] = b.w[3]; c.r[rd] = o.r; }
static inline void mmi_pexew(Ctx& c, int rd, int rt) { V128 b = V(c.r[rt]), o; o.w[0] = b.w[2]; o.w[1] = b.w[1]; o.w[2] = b.w[0]; o.w[3] = b.w[3]; c.r[rd] = o.r; }

// PMFHI/PMFLO juntam HI/HI1 e LO/LO1 em um registrador de 128 bits.
static inline void mmi_pmfhi(Ctx& c, int rd) { Reg128 o = { c.hi, c.hi1 }; c.r[rd] = o; }
static inline void mmi_pmflo(Ctx& c, int rd) { Reg128 o = { c.lo, c.lo1 }; c.r[rd] = o; }

// MADD: (HI, LO) += rs * rt, com sinal; o EE tambem grava LO em rd.
static inline void ee_madd(Ctx& c, int rd, int rs, int rt)
{
    int64_t acc = (int64_t)(((uint64_t)(uint32_t)c.hi << 32) | (uint32_t)c.lo);
    acc += (int64_t)(int32_t)c.r[rs].lo * (int64_t)(int32_t)c.r[rt].lo;
    c.lo = S32((uint32_t)acc);
    c.hi = S32((uint32_t)((uint64_t)acc >> 32));
    if (rd != 0) c.r[rd].lo = c.lo;
}

// Pontos de entrada do runtime (a implementar).
void ps2_call(Ctx& c, uint32_t target);
void ps2_tailcall(Ctx& c, uint32_t target);
void ps2_syscall(Ctx& c);
void ps2_break(Ctx& c, uint32_t address);
void ps2_ei(Ctx& c);
void ps2_di(Ctx& c);
uint32_t ps2_mfc0(Ctx& c, int reg);
void ps2_mtc0(Ctx& c, int reg, uint32_t value);
void ps2_unsupported(Ctx& c, uint32_t address, const char* mnemonic);
";

    // Runtime minimo (ps2_runtime.cpp): despacho por endereco usando a tabela
    // gerada e paradas claras para o que ainda nao existe.
    public const string RuntimeSource = """
#include "ps2_functions.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>

const char* ps2_syscall_name(int number);   // gerado em ps2_syscall_names.cpp

typedef void (*Ps2Func)(Ctx&);

static const Ps2FuncEntry* find_entry(uint32_t address)
{
    unsigned lo = 0;
    unsigned hi = ps2_function_count;

    while (lo < hi)
    {
        unsigned mid = (lo + hi) / 2;
        uint32_t a = ps2_function_table[mid].address;

        if (a == address) return &ps2_function_table[mid];
        if (a < address) lo = mid + 1; else hi = mid;
    }

    return nullptr;
}

#ifdef PS2_TRACE
static uint32_t g_ring[64];
static unsigned g_ring_pos = 0;

void ps2_trace_enter(uint32_t address) { g_ring[g_ring_pos++ & 63u] = address; }
#endif

static void dump_trace()
{
#ifdef PS2_TRACE
    unsigned count = g_ring_pos < 32 ? g_ring_pos : 32;

    std::fprintf(stderr, "ultimas funcoes (da mais antiga para a mais recente):\n");

    for (unsigned i = count; i > 0; i--)
    {
        uint32_t a = g_ring[(g_ring_pos - i) & 63u];
        const Ps2FuncEntry* e = find_entry(a);

        std::fprintf(stderr, "  0x%08X  %s\n", a, e ? e->name : "?");
    }
#else
    std::fprintf(stderr, "(compile com -DPS2_TRACE para ver as ultimas funcoes)\n");
#endif
}

[[noreturn]] static void die()
{
    dump_trace();
    std::fflush(stderr);
    std::abort();
}

void ps2_call(Ctx& c, uint32_t target)
{
    const Ps2FuncEntry* e = find_entry(target);

    if (!e)
    {
        std::fprintf(stderr, "ps2_call: 0x%08X nao e inicio de funcao conhecida\n", target);
        die();
    }

    e->fn(c);
}

// JR indireto: o destino precisa ser o inicio de uma funcao (tail call).
void ps2_tailcall(Ctx& c, uint32_t target)
{
    const Ps2FuncEntry* e = find_entry(target);

    if (!e)
    {
        std::fprintf(stderr, "salto indireto para 0x%08X, que nao e inicio de funcao (longjmp ou catch?)\n", target);
        die();
    }

    e->fn(c);
}

// ---- hardware: por enquanto so registra os primeiros acessos ----

static unsigned g_hw_log = 0;
static uint32_t g_poll_address = 0;
static unsigned g_poll_count = 0;

uint64_t ps2_hw_read(Ctx&, uint32_t phys, int size)
{
    if (g_hw_log < 300)
    {
        g_hw_log++;
        std::fprintf(stderr, "hw leitura  0x%08X (%d bytes)\n", phys, size);
    }

    // Muitas leituras seguidas do mesmo registrador: o jogo espera por algo que nao vem.
    if (phys == g_poll_address)
    {
        if (++g_poll_count >= 300000u)
        {
            std::fprintf(stderr, "laco de espera: 0x%08X lido %u vezes seguidas\n", phys, g_poll_count);
            die();
        }
    }
    else
    {
        g_poll_address = phys;
        g_poll_count = 0;
    }

    return 0;
}

void ps2_hw_write(Ctx&, uint32_t phys, uint64_t value, int size)
{
    if (g_hw_log < 300)
    {
        g_hw_log++;
        std::fprintf(stderr, "hw escrita  0x%08X (%d bytes) = 0x%llX\n", phys, size, (unsigned long long)value);
    }

    g_poll_address = 0;
    g_poll_count = 0;
}

void ps2_bad_address(Ctx&, uint32_t address, int write)
{
    std::fprintf(stderr, "acesso de %s a endereco fora do mapa: 0x%08X\n", write ? "escrita" : "leitura", address);
    die();
}

// ---- syscalls do kernel do EE: so as que o inicio do jogo precisa ----

static uint32_t g_stack_base = 0x01F80000u;
static uint32_t g_heap_start = 0;
static uint32_t g_heap_end = 0;
static uint32_t g_next_id = 1;
static unsigned g_syscall_log = 0;
static uint32_t g_user_syscall[512];   // funcoes instaladas por SetSyscall, indice = numero + 256

void ps2_syscall(Ctx& c)
{
    int number = (int)(int16_t)c.r[3].lo;

    // os primeiros 200 syscalls ficam no log, para conhecer a sequencia de inicializacao
    if (g_syscall_log < 200)
    {
        g_syscall_log++;
        std::fprintf(stderr, "syscall %d (%s)\n", number, ps2_syscall_name(number));
    }

    // Syscall instalado pelo proprio programa (SetSyscall): e uma chamada normal da funcao.
    if (number >= -256 && number < 256 && g_user_syscall[number + 256] != 0)
    {
        ps2_call(c, g_user_syscall[number + 256]);
        return;
    }

    switch (number)
    {
        case 116:  // SetSyscall(numero, funcao): devolve a funcao anterior
        {
            int target = (int)(int32_t)c.r[4].lo;
            uint32_t function = (uint32_t)c.r[5].lo;

            std::fprintf(stderr, "  SetSyscall numero=%d funcao=0x%08X\n", target, function);

            if (target >= -256 && target < 256)
            {
                c.r[2].lo = g_user_syscall[target + 256];
                g_user_syscall[target + 256] = function;
            }
            else
            {
                c.r[2].lo = 0;
            }

            return;
        }

        case 60:   // SetupThread(gp, stack, stack_size, args, root_func): devolve o novo $sp
        {
            uint32_t stack = (uint32_t)c.r[5].lo;
            uint32_t size = (uint32_t)c.r[6].lo;

            if (stack == 0xFFFFFFFFu) stack = 0x02000000u - size;

            g_stack_base = stack;
            c.r[28].lo = c.r[4].lo;
            c.r[2].lo = S32(stack + size - 0x2A0u);
            return;
        }

        case 61:   // InitHeap(heap_start, heap_size): tamanho -1 = ate a base da pilha
        {
            uint32_t start = (uint32_t)c.r[4].lo;
            uint32_t size = (uint32_t)c.r[5].lo;

            g_heap_start = start;
            g_heap_end = size == 0xFFFFFFFFu ? g_stack_base : start + size;
            c.r[2].lo = start;
            return;
        }

        case 62:   // EndOfHeap
            c.r[2].lo = g_heap_end != 0 ? g_heap_end : g_stack_base;
            return;

        case 2:    // SetGsCrt(interlaced, mode, ffmd): por enquanto so registra
            std::fprintf(stderr, "  SetGsCrt interlace=%u modo=%u ffmd=%u\n",
                (unsigned)c.r[4].lo, (unsigned)c.r[5].lo, (unsigned)c.r[6].lo);
            c.r[2].lo = 0;
            return;

        case 16: case 18:   // AddIntcHandler(causa, handler, next, arg) / AddDmacHandler(canal, handler, next, arg)
            std::fprintf(stderr, "  %s causa/canal=%u handler=0x%08X\n",
                number == 16 ? "AddIntcHandler" : "AddDmacHandler",
                (unsigned)c.r[4].lo, (unsigned)c.r[5].lo);
            c.r[2].lo = g_next_id++;
            return;

        case 17: case 19:                  // Remove*Handler
        case 20: case 21: case 22: case 23:  // _EnableIntc, _DisableIntc, _EnableDmac, _DisableDmac
        case -26: case -27: case -28: case -29:   // versoes i
        case 92: case 93: case 94: case 95:       // Enable/Disable*Handler
        case -92: case -93: case -94: case -95:
            c.r[2].lo = 0;
            return;

        case 47:   // GetThreadId: so existe a thread principal
            c.r[2].lo = 1;
            return;

        case 97: case 98: case 100: case -104:   // EnableCache, DisableCache, FlushCache, iFlushCache
        case 124:                                // Deci2Call (depuracao)
            c.r[2].lo = 0;
            return;

        case 127:  // GetMemorySize
            c.r[2].lo = 0x02000000ull;
            return;

        default:
            std::fprintf(stderr, "syscall %d (%s) ainda nao implementada\n", number, ps2_syscall_name(number));
            die();
    }
}

void ps2_break(Ctx&, uint32_t address)
{
    std::fprintf(stderr, "BREAK em 0x%08X\n", address);
    die();
}

void ps2_unsupported(Ctx&, uint32_t address, const char* mnemonic)
{
    std::fprintf(stderr, "instrucao sem suporte em 0x%08X (%s)\n", address, mnemonic);
    die();
}

void ps2_ei(Ctx&) {}
void ps2_di(Ctx&) {}
uint32_t ps2_mfc0(Ctx&, int) { return 0; }
void ps2_mtc0(Ctx&, int, uint32_t) {}
""";

    public static string FunctionName(ElfSymbol function)
    {
        string clean = Regex.Replace(function.Name, "[^A-Za-z0-9_]", "_");

        return $"f_{function.Address:X8}_{clean}";
    }

    public static Result EmitFunction(
        ElfImage image,
        ElfSymbol function,
        IReadOnlyDictionary<uint, string>? names = null,
        JumpTableResolver? jumpTables = null,
        IReadOnlyDictionary<uint, string>? directCalls = null,
        bool comments = true,
        bool includeHeader = true)
    {
        Writer writer = new(names, jumpTables, directCalls, comments, includeHeader);

        return writer.Emit(image, function);
    }

    private static bool HasDelaySlot(MipsInstruction instruction)
    {
        return instruction.IsRelativeBranch ||
               instruction.Mnemonic is "J" or "JAL" or "JR" or "JALR";
    }

    private static bool IsCall(MipsInstruction instruction)
    {
        return instruction.Mnemonic == "JAL" ||
               instruction.IsBranchAndLink;
    }

    private static string Lo(int register) => $"c.r[{register}].lo";

    private static HashSet<uint> CollectLabels(
        MipsInstruction[] code,
        uint start,
        uint end,
        IEnumerable<uint> extraTargets)
    {
        HashSet<uint> labels = new();

        // Destinos de jump tables.
        foreach (uint target in extraTargets)
        {
            if (target >= start && target < end)
                labels.Add(target);
        }

        for (int i = 0; i < code.Length; i++)
        {
            uint address = start + (uint)(i * 4);

            if (IsCall(code[i]))
                continue;

            if (code[i].TryGetBranchTarget(address, out uint target) &&
                target >= start &&
                target < end)
            {
                labels.Add(target);
            }
        }

        // Delay slot que tambem e alvo de salto: a instrucao seguinte
        // precisa de um label para o caminho que nao passa pelo slot.
        for (int i = 0; i + 2 < code.Length; i++)
        {
            if (HasDelaySlot(code[i]) &&
                labels.Contains(start + (uint)((i + 1) * 4)))
            {
                labels.Add(start + (uint)((i + 2) * 4));
            }
        }

        return labels;
    }

    private static string? Condition(MipsInstruction i)
    {
        string rs = Lo(i.Rs);
        string rt = Lo(i.Rt);

        return i.Mnemonic switch
        {
            "BEQ" or "BEQL" => $"{rs} == {rt}",
            "BNE" or "BNEL" => $"{rs} != {rt}",
            "BLEZ" or "BLEZL" => $"(int64_t){rs} <= 0",
            "BGTZ" or "BGTZL" => $"(int64_t){rs} > 0",
            "BLTZ" or "BLTZL" or "BLTZAL" or "BLTZALL" => $"(int64_t){rs} < 0",
            "BGEZ" or "BGEZL" or "BGEZAL" or "BGEZALL" => $"(int64_t){rs} >= 0",
            "BC1T" or "BC1TL" => "(c.fcr31 & 0x00800000u) != 0",
            "BC1F" or "BC1FL" => "(c.fcr31 & 0x00800000u) == 0",
            _ => null
        };
    }

    // Uma instrucao simples. "" = nada a emitir; null = sem suporte.
    private static string? Statement(MipsInstruction i, uint pc)
    {
        if (i.IsVu0Macro)
            return Vu0Statement(i);

        int rs = i.Rs;
        int rt = i.Rt;
        int rd = i.Rd;
        int sa = i.Shamt;

        string rsLo = Lo(rs);
        string rtLo = Lo(rt);

        uint simm32 = unchecked((uint)(int)i.SignedImmediate);
        long simm64 = i.SignedImmediate;
        uint uimm = i.Immediate;

        string address = $"(uint32_t){rsLo} + 0x{simm32:X}u";

        string SetRd(string expression) =>
            rd == 0
                ? "/* destino e $zero */"
                : $"{Lo(rd)} = {expression};";

        string SetRt(string expression) =>
            rt == 0
                ? "/* destino e $zero */"
                : $"{Lo(rt)} = {expression};";

        switch (i.Mnemonic)
        {
            case "NOP":
            case "SYNC":
                return "";

            case "SYSCALL":
                return "ps2_syscall(c);";

            // 32 bits (resultado estendido com sinal)
            case "ADDIU":
            case "ADDI":
                return SetRt($"S32((uint32_t){rsLo} + 0x{simm32:X}u)");

            case "ADDU":
            case "ADD":
                return SetRd($"S32((uint32_t){rsLo} + (uint32_t){rtLo})");

            case "SUBU":
            case "SUB":
                return SetRd($"S32((uint32_t){rsLo} - (uint32_t){rtLo})");

            // 64 bits
            case "DADDIU":
            case "DADDI":
                return SetRt($"{rsLo} + (uint64_t)({simm64}LL)");

            case "DADDU":
            case "DADD":
                return SetRd($"{rsLo} + {rtLo}");

            case "DSUBU":
            case "DSUB":
                return SetRd($"{rsLo} - {rtLo}");

            // logicas
            case "AND": return SetRd($"{rsLo} & {rtLo}");
            case "OR": return SetRd($"{rsLo} | {rtLo}");
            case "XOR": return SetRd($"{rsLo} ^ {rtLo}");
            case "NOR": return SetRd($"~({rsLo} | {rtLo})");

            case "ANDI": return SetRt($"{rsLo} & 0x{uimm:X}ull");
            case "ORI": return SetRt($"{rsLo} | 0x{uimm:X}ull");
            case "XORI": return SetRt($"{rsLo} ^ 0x{uimm:X}ull");

            case "LUI":
                uint upper = uimm << 16;
                return SetRt($"S32(0x{upper:X8}u)");

            // comparacoes
            case "SLT":
                return SetRd($"((int64_t){rsLo} < (int64_t){rtLo}) ? 1 : 0");

            case "SLTU":
                return SetRd($"({rsLo} < {rtLo}) ? 1 : 0");

            case "SLTI":
                return SetRt($"((int64_t){rsLo} < {simm64}LL) ? 1 : 0");

            case "SLTIU":
                return SetRt($"({rsLo} < (uint64_t)({simm64}LL)) ? 1 : 0");

            // deslocamentos
            case "SLL":
                return SetRd($"S32((uint32_t){rtLo} << {sa})");

            case "SRL":
                return SetRd($"S32((uint32_t){rtLo} >> {sa})");

            case "SRA":
                return SetRd($"(uint64_t)(int64_t)((int32_t){rtLo} >> {sa})");

            case "SLLV":
                return SetRd($"S32((uint32_t){rtLo} << ({rsLo} & 31))");

            case "SRLV":
                return SetRd($"S32((uint32_t){rtLo} >> ({rsLo} & 31))");

            case "SRAV":
                return SetRd($"(uint64_t)(int64_t)((int32_t){rtLo} >> ({rsLo} & 31))");

            case "DSLL": return SetRd($"{rtLo} << {sa}");
            case "DSRL": return SetRd($"{rtLo} >> {sa}");
            case "DSRA": return SetRd($"(uint64_t)((int64_t){rtLo} >> {sa})");
            case "DSLL32": return SetRd($"{rtLo} << {sa + 32}");
            case "DSRL32": return SetRd($"{rtLo} >> {sa + 32}");
            case "DSRA32": return SetRd($"(uint64_t)((int64_t){rtLo} >> {sa + 32})");

            case "MOVZ":
                return rd == 0 ? "" : $"if ({rtLo} == 0) {Lo(rd)} = {rsLo};";

            case "MOVN":
                return rd == 0 ? "" : $"if ({rtLo} != 0) {Lo(rd)} = {rsLo};";

            // cargas
            case "LB": return SetRt($"(uint64_t)(int64_t)mrd<int8_t>(c, {address})");
            case "LBU": return SetRt($"mrd<uint8_t>(c, {address})");
            case "LH": return SetRt($"(uint64_t)(int64_t)mrd<int16_t>(c, {address})");
            case "LHU": return SetRt($"mrd<uint16_t>(c, {address})");
            case "LW": return SetRt($"S32(mrd<uint32_t>(c, {address}))");
            case "LWU": return SetRt($"mrd<uint32_t>(c, {address})");
            case "LD": return SetRt($"mrd<uint64_t>(c, {address})");

            case "LQ":
                return rt == 0
                    ? ""
                    : $"c.r[{rt}] = mrd<Reg128>(c, ({address}) & ~15u);";

            // gravacoes
            case "SB": return $"mwr<uint8_t>(c, {address}, (uint8_t){rtLo});";
            case "SH": return $"mwr<uint16_t>(c, {address}, (uint16_t){rtLo});";
            case "SW": return $"mwr<uint32_t>(c, {address}, (uint32_t){rtLo});";
            case "SD": return $"mwr<uint64_t>(c, {address}, {rtLo});";
            case "SQ": return $"mwr<Reg128>(c, ({address}) & ~15u, c.r[{rt}]);";

            // PADDUB rd, rs, $zero e o move de 128 bits do Metrowerks
            case "PADDUB":
                if (rd == 0)
                    return "";

                return rt == 0
                    ? $"c.r[{rd}] = c.r[{rs}];"
                    : $"mmi_paddub(c, {rd}, {rs}, {rt});";

            default:
                return TemplateFor(i, pc, address);
        }
    }

    // VU0 em modo macro. Campos: dest = Rs & 0xF, fd = Shamt, fs = Rd, ft = Rt.
    private static string? Vu0Statement(MipsInstruction i)
    {
        int dest = i.Rs & 0xF;
        int fd = i.Shamt;
        int fs = i.Rd;
        int ft = i.Rt;
        int fsf = i.Rs & 3;
        int ftf = (i.Rs >> 2) & 3;
        string name = i.Mnemonic;

        if (Vu0.TryParseArith(name, out string op, out string source, out bool toAcc))
        {
            return $"vu_arith(c, VU_{op}, VU_SRC_{source}, {dest}, {fd}, {fs}, {ft}, {(toAcc ? 1 : 0)});";
        }

        int imm5 = i.Shamt >= 16 ? i.Shamt - 32 : i.Shamt;

        return name switch
        {
            "VNOP" or "VWAITQ" => "",

            "VOPMSUB" => $"vu_opmsub(c, {fd}, {fs}, {ft});",
            "VOPMULA" => $"vu_opmula(c, {fs}, {ft});",

            "VMOVE" => $"vu_move(c, {dest}, {ft}, {fs});",
            "VMR32" => $"vu_mr32(c, {dest}, {ft}, {fs});",
            "VABS" => $"vu_abs(c, {dest}, {ft}, {fs});",

            "VITOF0" => $"vu_itof(c, {dest}, {ft}, {fs}, 0);",
            "VITOF4" => $"vu_itof(c, {dest}, {ft}, {fs}, 4);",
            "VITOF12" => $"vu_itof(c, {dest}, {ft}, {fs}, 12);",
            "VITOF15" => $"vu_itof(c, {dest}, {ft}, {fs}, 15);",

            "VFTOI0" => $"vu_ftoi(c, {dest}, {ft}, {fs}, 0);",
            "VFTOI4" => $"vu_ftoi(c, {dest}, {ft}, {fs}, 4);",
            "VFTOI12" => $"vu_ftoi(c, {dest}, {ft}, {fs}, 12);",
            "VFTOI15" => $"vu_ftoi(c, {dest}, {ft}, {fs}, 15);",

            "VCLIPw" => $"vu_clipw(c, {fs}, {ft});",

            "VDIV" => $"vu_div(c, {fs}, {fsf}, {ft}, {ftf});",
            "VSQRT" => $"vu_sqrt(c, {ft}, {ftf});",
            "VRSQRT" => $"vu_rsqrt(c, {fs}, {fsf}, {ft}, {ftf});",

            "VIADD" => $"vu_iadd(c, {fd}, {fs}, {ft});",
            "VISUB" => $"vu_isub(c, {fd}, {fs}, {ft});",
            "VIAND" => $"vu_iand(c, {fd}, {fs}, {ft});",
            "VIOR" => $"vu_ior(c, {fd}, {fs}, {ft});",
            "VIADDI" => $"vu_iaddi(c, {ft}, {fs}, {imm5});",

            "VMTIR" => $"vu_mtir(c, {ft}, {fs}, {fsf});",
            "VMFIR" => $"vu_mfir(c, {dest}, {ft}, {fs});",

            _ => null
        };
    }

    // Instrucoes cujo destino e o campo rd / rt (escritas em $zero sao puladas).
    private static readonly HashSet<string> WritesRd = new()
    {
        "MFHI", "MFLO", "MFHI1", "MFLO1", "DSLLV", "DSRLV", "DSRAV",
        "PAND", "POR", "PXOR", "PNOR", "PCPYLD", "PCPYUD",
        "PADDW", "PSUBW", "PADDH", "PSUBH", "PADDB", "PSUBB",
        "PSLLH", "PSRLH", "PSRAH", "PSLLW", "PSRLW", "PSRAW",
        "PEXTLB", "PEXTUB", "PEXTLH", "PEXTUH", "PEXTLW", "PEXTUW",
        "QFSRV",
        "PCGTH", "PMINH", "PMAXH", "PMINW", "PSUBUB", "PADDUH", "PPACB", "PPACH",
        "PCPYH", "PEXCW", "PEXEW", "PMFHI", "PMFLO"
    };

    private static readonly HashSet<string> WritesRt = new()
    {
        "MFC1", "MFC0", "LWL", "LWR", "LDL", "LDR", "QMFC2", "CFC2"
    };

    // Instrucoes que viram uma linha de C++ a partir de um modelo. Campos:
    // {fd} {fs} {ft} (COP1), {rs} {rt} {rd}, {sa}, {imm}, {rsLo} {rtLo}, {addr}, {pc}.
    // Sem aspas nem barras invertidas aqui dentro.
    private static readonly Dictionary<string, string> Templates = new()
    {
        // FPU: movimentacao e memoria
        ["MTC1"] = "c.f[{fs}] = (uint32_t){rtLo};",
        ["MFC1"] = "c.r[{rt}].lo = S32(c.f[{fs}]);",
        ["LWC1"] = "c.f[{ft}] = mrd<uint32_t>(c, {addr});",
        ["SWC1"] = "mwr<uint32_t>(c, {addr}, c.f[{ft}]);",

        // FPU: aritmetica
        ["ADD.S"] = "fpu_add(c, {fd}, {fs}, {ft});",
        ["SUB.S"] = "fpu_sub(c, {fd}, {fs}, {ft});",
        ["MUL.S"] = "fpu_mul(c, {fd}, {fs}, {ft});",
        ["DIV.S"] = "fpu_div(c, {fd}, {fs}, {ft});",
        ["SQRT.S"] = "fpu_sqrt(c, {fd}, {ft});",
        ["RSQRT.S"] = "fpu_rsqrt(c, {fd}, {fs}, {ft});",
        ["ABS.S"] = "c.f[{fd}] = c.f[{fs}] & 0x7FFFFFFFu;",
        ["NEG.S"] = "c.f[{fd}] = c.f[{fs}] ^ 0x80000000u;",
        ["MOV.S"] = "c.f[{fd}] = c.f[{fs}];",
        ["MAX.S"] = "fpu_max(c, {fd}, {fs}, {ft});",
        ["MIN.S"] = "fpu_min(c, {fd}, {fs}, {ft});",

        // FPU: acumulador
        ["ADDA.S"] = "fpu_adda(c, {fs}, {ft});",
        ["SUBA.S"] = "fpu_suba(c, {fs}, {ft});",
        ["MULA.S"] = "fpu_mula(c, {fs}, {ft});",
        ["MADD.S"] = "fpu_madd(c, {fd}, {fs}, {ft});",
        ["MSUB.S"] = "fpu_msub(c, {fd}, {fs}, {ft});",
        ["MADDA.S"] = "fpu_madda(c, {fs}, {ft});",
        ["MSUBA.S"] = "fpu_msuba(c, {fs}, {ft});",

        // FPU: conversao e comparacao
        ["CVT.S.W"] = "fpu_cvt_s_w(c, {fd}, {fs});",
        ["CVT.W.S"] = "fpu_cvt_w_s(c, {fd}, {fs});",
        ["C.F.S"] = "fpu_set_c(c, false);",
        ["C.EQ.S"] = "fpu_c_eq(c, {fs}, {ft});",
        ["C.LT.S"] = "fpu_c_lt(c, {fs}, {ft});",
        ["C.LE.S"] = "fpu_c_le(c, {fs}, {ft});",

        // multiplicacao e divisao inteira
        ["MFHI"] = "c.r[{rd}].lo = c.hi;",
        ["MFLO"] = "c.r[{rd}].lo = c.lo;",
        ["MTHI"] = "c.hi = {rsLo};",
        ["MTLO"] = "c.lo = {rsLo};",
        ["MULT"] = "ee_mult(c, {rd}, {rs}, {rt});",
        ["MULTU"] = "ee_multu(c, {rd}, {rs}, {rt});",
        ["DIV"] = "ee_div(c, {rs}, {rt});",
        ["DIVU"] = "ee_divu(c, {rs}, {rt});",

        // multiplicacao/divisao do pipeline 1
        ["MULT1"] = "ee_mult1(c, {rd}, {rs}, {rt});",
        ["MULTU1"] = "ee_multu1(c, {rd}, {rs}, {rt});",
        ["DIV1"] = "ee_div1(c, {rs}, {rt});",
        ["DIVU1"] = "ee_divu1(c, {rs}, {rt});",
        ["MFHI1"] = "c.r[{rd}].lo = c.hi1;",
        ["MFLO1"] = "c.r[{rd}].lo = c.lo1;",
        ["MTHI1"] = "c.hi1 = {rsLo};",
        ["MTLO1"] = "c.lo1 = {rsLo};",

        // deslocamentos variaveis de 64 bits
        ["DSLLV"] = "c.r[{rd}].lo = {rtLo} << ({rsLo} & 63);",
        ["DSRLV"] = "c.r[{rd}].lo = {rtLo} >> ({rsLo} & 63);",
        ["DSRAV"] = "c.r[{rd}].lo = (uint64_t)((int64_t){rtLo} >> ({rsLo} & 63));",

        // cargas e gravacoes desalinhadas
        ["LWL"] = "ee_lwl(c, {rt}, {addr});",
        ["LWR"] = "ee_lwr(c, {rt}, {addr});",
        ["SWL"] = "ee_swl(c, {rt}, {addr});",
        ["SWR"] = "ee_swr(c, {rt}, {addr});",
        ["LDL"] = "ee_ldl(c, {rt}, {addr});",
        ["LDR"] = "ee_ldr(c, {rt}, {addr});",
        ["SDL"] = "ee_sdl(c, {rt}, {addr});",
        ["SDR"] = "ee_sdr(c, {rt}, {addr});",

        // cache e prefetch nao tem efeito no host
        ["CACHE"] = "",
        ["PREF"] = "",

        // COP0
        ["MFC0"] = "c.r[{rt}].lo = S32(ps2_mfc0(c, {rd}));",
        ["MTC0"] = "ps2_mtc0(c, {rd}, (uint32_t){rtLo});",

        // MMI
        ["PAND"] = "mmi_pand(c, {rd}, {rs}, {rt});",
        ["POR"] = "mmi_por(c, {rd}, {rs}, {rt});",
        ["PXOR"] = "mmi_pxor(c, {rd}, {rs}, {rt});",
        ["PNOR"] = "mmi_pnor(c, {rd}, {rs}, {rt});",
        ["PCPYLD"] = "mmi_pcpyld(c, {rd}, {rs}, {rt});",
        ["PCPYUD"] = "mmi_pcpyud(c, {rd}, {rs}, {rt});",
        ["PADDW"] = "mmi_paddw(c, {rd}, {rs}, {rt});",
        ["PSUBW"] = "mmi_psubw(c, {rd}, {rs}, {rt});",
        ["PADDH"] = "mmi_paddh(c, {rd}, {rs}, {rt});",
        ["PSUBH"] = "mmi_psubh(c, {rd}, {rs}, {rt});",
        ["PADDB"] = "mmi_paddb(c, {rd}, {rs}, {rt});",
        ["PSUBB"] = "mmi_psubb(c, {rd}, {rs}, {rt});",
        ["PSLLH"] = "mmi_psllh(c, {rd}, {rt}, {sa});",
        ["PSRLH"] = "mmi_psrlh(c, {rd}, {rt}, {sa});",
        ["PSRAH"] = "mmi_psrah(c, {rd}, {rt}, {sa});",
        ["PSLLW"] = "mmi_psllw(c, {rd}, {rt}, {sa});",
        ["PSRLW"] = "mmi_psrlw(c, {rd}, {rt}, {sa});",
        ["PSRAW"] = "mmi_psraw(c, {rd}, {rt}, {sa});",
        ["PEXTLB"] = "mmi_pextlb(c, {rd}, {rs}, {rt});",
        ["PEXTUB"] = "mmi_pextub(c, {rd}, {rs}, {rt});",
        ["PEXTLH"] = "mmi_pextlh(c, {rd}, {rs}, {rt});",
        ["PEXTUH"] = "mmi_pextuh(c, {rd}, {rs}, {rt});",
        ["PEXTLW"] = "mmi_pextlw(c, {rd}, {rs}, {rt});",
        ["PEXTUW"] = "mmi_pextuw(c, {rd}, {rs}, {rt});",
        ["QFSRV"] = "mmi_qfsrv(c, {rd}, {rs}, {rt});",
        ["MTSAB"] = "ee_mtsab(c, {rs}, {imm});",
        ["MTSAH"] = "ee_mtsah(c, {rs}, {imm});",

        // MMI: comparacoes, min/max, pack, trocas
        ["PCGTH"] = "mmi_pcgth(c, {rd}, {rs}, {rt});",
        ["PMINH"] = "mmi_pminh(c, {rd}, {rs}, {rt});",
        ["PMAXH"] = "mmi_pmaxh(c, {rd}, {rs}, {rt});",
        ["PMINW"] = "mmi_pminw(c, {rd}, {rs}, {rt});",
        ["PSUBUB"] = "mmi_psubub(c, {rd}, {rs}, {rt});",
        ["PADDUH"] = "mmi_padduh(c, {rd}, {rs}, {rt});",
        ["PPACB"] = "mmi_ppacb(c, {rd}, {rs}, {rt});",
        ["PPACH"] = "mmi_ppach(c, {rd}, {rs}, {rt});",
        ["PCPYH"] = "mmi_pcpyh(c, {rd}, {rt});",
        ["PEXCW"] = "mmi_pexcw(c, {rd}, {rt});",
        ["PEXEW"] = "mmi_pexew(c, {rd}, {rt});",
        ["PMFHI"] = "mmi_pmfhi(c, {rd});",
        ["PMFLO"] = "mmi_pmflo(c, {rd});",
        ["MADD"] = "ee_madd(c, {rd}, {rs}, {rt});",

        // interrupcoes (COP0)
        ["EI"] = "ps2_ei(c);",
        ["DI"] = "ps2_di(c);",

        // COP2: transferencias e memoria
        ["QMFC2"] = "c.r[{rt}] = vu_qmfc2(c, {rd});",
        ["QMTC2"] = "vu_qmtc2(c, {rd}, c.r[{rt}]);",
        ["CFC2"] = "c.r[{rt}].lo = S32(vu_cfc2(c, {rd}));",
        ["CTC2"] = "vu_ctc2(c, {rd}, (uint32_t){rtLo});",
        ["LQC2"] = "vu_qmtc2(c, {rt}, mrd<Reg128>(c, ({addr}) & ~15u));",
        ["SQC2"] = "mwr<Reg128>(c, ({addr}) & ~15u, vu_qmfc2(c, {rt}));",

        ["BREAK"] = "ps2_break(c, {pc});"
    };

    private static string? TemplateFor(MipsInstruction i, uint pc, string addr)
    {
        // Destinos em $zero: nada a gravar.
        if (WritesRd.Contains(i.Mnemonic) && i.Rd == 0)
            return "";

        if (WritesRt.Contains(i.Mnemonic) && i.Rt == 0)
            return "";

        // Registradores de controle da FPU: so o fcr31 (e o fcr0, so leitura).
        if (i.Mnemonic == "CFC1")
        {
            if (i.Rt == 0)
                return "";

            return i.Rd switch
            {
                31 => $"c.r[{i.Rt}].lo = S32(c.fcr31);",
                0 => $"c.r[{i.Rt}].lo = 0x2E00ull;",
                _ => $"c.r[{i.Rt}].lo = 0;"
            };
        }

        if (i.Mnemonic == "CTC1")
        {
            return i.Rd == 31
                ? $"c.fcr31 = (uint32_t){Lo(i.Rt)};"
                : "";
        }

        if (!Templates.TryGetValue(i.Mnemonic, out string? template))
            return null;

        return template
            .Replace("{fd}", i.Shamt.ToString())
            .Replace("{fs}", i.Rd.ToString())
            .Replace("{ft}", i.Rt.ToString())
            .Replace("{rs}", i.Rs.ToString())
            .Replace("{rt}", i.Rt.ToString())
            .Replace("{rd}", i.Rd.ToString())
            .Replace("{sa}", i.Shamt.ToString())
            .Replace("{imm}", i.Immediate.ToString())
            .Replace("{rsLo}", Lo(i.Rs))
            .Replace("{rtLo}", Lo(i.Rt))
            .Replace("{addr}", addr)
            .Replace("{pc}", $"0x{pc:X8}u");
    }

    private sealed class Writer
    {
        private const string I1 = "    ";
        private const string I2 = "        ";

        private readonly StringBuilder _sb = new();
        private readonly IReadOnlyDictionary<uint, string>? _names;
        private readonly Dictionary<string, int> _byMnemonic = new();
        private readonly JumpTableResolver? _jumpTables;
        private readonly Dictionary<uint, JumpTableResolver.Table> _tables = new();
        private readonly IReadOnlyDictionary<uint, string>? _directCalls;
        private readonly bool _comments;
        private readonly bool _includeHeader;
        private int _unsupported;
        private int _dispatched;

        public Writer(
            IReadOnlyDictionary<uint, string>? names,
            JumpTableResolver? jumpTables,
            IReadOnlyDictionary<uint, string>? directCalls,
            bool comments,
            bool includeHeader)
        {
            _names = names;
            _jumpTables = jumpTables;
            _directCalls = directCalls;
            _comments = comments;
            _includeHeader = includeHeader;
        }

        // Comentarios so quando pedidos (o executavel inteiro gera dezenas de MB).
        private void Comment(string indent, string text)
        {
            if (_comments)
                _sb.AppendLine($"{indent}// {text}");
        }

        public Result Emit(ElfImage image, ElfSymbol function)
        {
            uint start = function.Address;
            int count = checked((int)(function.Size / 4));
            uint end = start + (uint)(count * 4);

            MipsInstruction[] code = new MipsInstruction[count];

            for (int i = 0; i < count; i++)
            {
                code[i] = MipsDecoder.Decode(
                    image.ReadUInt32(start + (uint)(i * 4)));
            }

            // JR em registrador que nao e $ra: tenta resolver como jump table.
            if (_jumpTables != null)
            {
                for (int i = 0; i < count; i++)
                {
                    if (code[i].Mnemonic != "JR" || code[i].Rs == 31)
                        continue;

                    if (_jumpTables.TryResolve(code, i, start, end, out JumpTableResolver.Table? table, out _) &&
                        table != null)
                    {
                        _tables[start + (uint)(i * 4)] = table;
                    }
                }
            }

            HashSet<uint> labels = CollectLabels(
                code,
                start,
                end,
                _tables.Values.SelectMany(t => t.Targets));

            if (_includeHeader)
            {
                _sb.AppendLine("#include \"ps2rt.h\"");
                _sb.AppendLine();
            }

            Comment("", $"{function.Name}  0x{start:X8}  ({function.Size} bytes)");
            _sb.AppendLine($"void {FunctionName(function)}(Ctx& c)");
            _sb.AppendLine("{");
            _sb.AppendLine($"{I1}PS2_TRACE_ENTER(0x{start:X8}u);");

            for (int i = 0; i < count; i++)
            {
                uint address = start + (uint)(i * 4);
                MipsInstruction instruction = code[i];

                bool isDelaySlot = i > 0 && HasDelaySlot(code[i - 1]);
                bool isLabel = labels.Contains(address);

                if (isLabel)
                    _sb.AppendLine($"L_{address:X8}:");

                // Ja foi emitido junto do branch anterior.
                if (isDelaySlot && !isLabel)
                    continue;

                if (HasDelaySlot(instruction))
                {
                    MipsInstruction? delay =
                        i + 1 < count ? code[i + 1] : null;

                    Control(instruction, address, delay, start, end);

                    // O proximo e um delay slot que tambem e alvo: o
                    // caminho normal precisa pula-lo.
                    if (labels.Contains(address + 4) && address + 8 < end)
                        _sb.AppendLine($"{I1}goto L_{address + 8:X8};");
                }
                else
                {
                    Simple(instruction, address, I1);
                }
            }

            _sb.AppendLine("}");

            return new Result(_sb.ToString(), count, _unsupported, _byMnemonic, _dispatched);
        }

        private void Simple(MipsInstruction instruction, uint address, string indent)
        {
            Comment(indent, $"0x{address:X8}  {instruction.Format(address)}");

            string? statement = Statement(instruction, address);

            if (statement == null)
            {
                Unsupported(instruction, address, indent);
                return;
            }

            if (statement.Length > 0)
                _sb.AppendLine($"{indent}{statement}");
        }

        private void Unsupported(MipsInstruction instruction, uint address, string indent)
        {
            _unsupported++;
            _byMnemonic[instruction.Mnemonic] =
                _byMnemonic.GetValueOrDefault(instruction.Mnemonic) + 1;

            _sb.AppendLine(
                $"{indent}ps2_unsupported(c, 0x{address:X8}u, \"{instruction.Mnemonic}\");");
        }

        private void Delay(MipsInstruction? delay, uint branchAddress, string indent)
        {
            if (delay == null)
            {
                Comment(indent, "delay slot fora do simbolo da funcao");
                return;
            }

            if (HasDelaySlot(delay))
            {
                Comment(indent, "delay slot com branch/jump: nao suportado");
                Unsupported(delay, branchAddress + 4, indent);
                return;
            }

            Simple(delay, branchAddress + 4, indent);
        }

        // Chamada direta quando o destino e uma funcao conhecida; senao, pela tabela.
        private string CallTo(uint target)
        {
            string text;

            if (_directCalls != null && _directCalls.TryGetValue(target, out string? direct))
                text = $"{direct}(c);";
            else
                text = $"ps2_call(c, 0x{target:X8}u);";

            if (_comments && _names != null && _names.TryGetValue(target, out string? name))
                text += $"  // {name}";

            return text;
        }

        private string JumpTo(uint target, uint start, uint end)
        {
            if (target >= start && target < end)
                return $"goto L_{target:X8};";

            return $"{{ {CallTo(target)} return; }}";
        }

        private void Control(
            MipsInstruction instruction,
            uint address,
            MipsInstruction? delay,
            uint start,
            uint end)
        {
            string mnemonic = instruction.Mnemonic;
            uint link = address + 8;

            Comment(I1, $"0x{address:X8}  {instruction.Format(address)}");
            _sb.AppendLine($"{I1}{{");

            if (mnemonic == "JR")
            {
                if (instruction.Rs == 31)
                {
                    Delay(delay, address, I2);
                    _sb.AppendLine($"{I2}return;");
                }
                else if (_tables.TryGetValue(address, out JumpTableResolver.Table? table))
                {
                    // switch: o destino e lido antes do delay slot.
                    _sb.AppendLine($"{I2}uint32_t dest = (uint32_t){Lo(instruction.Rs)};");
                    Delay(delay, address, I2);
                    Comment(I2, $"jump table em 0x{table.TableAddress:X8}, {table.Targets.Count} destinos");
                    _sb.AppendLine($"{I2}switch (dest)");
                    _sb.AppendLine($"{I2}{{");

                    foreach (uint target in table.Targets)
                        _sb.AppendLine($"{I2}    case 0x{target:X8}u: goto L_{target:X8};");

                    _sb.AppendLine($"{I2}    default: ps2_unsupported(c, 0x{address:X8}u, \"JR\"); return;");
                    _sb.AppendLine($"{I2}}}");
                }
                else
                {
                    // Nao e jump table reconhecida: tail call por ponteiro de funcao
                    // (o callee volta para o nosso chamador via $ra). O runtime recusa
                    // destinos que nao sao inicio de funcao (longjmp, catch).
                    _dispatched++;
                    _sb.AppendLine($"{I2}uint32_t dest = (uint32_t){Lo(instruction.Rs)};");
                    Delay(delay, address, I2);
                    Comment(I2, "JR indireto: tail call por ponteiro");
                    _sb.AppendLine($"{I2}ps2_tailcall(c, dest);");
                    _sb.AppendLine($"{I2}return;");
                }
            }
            else if (mnemonic == "JALR")
            {
                _sb.AppendLine($"{I2}uint32_t dest = (uint32_t){Lo(instruction.Rs)};");

                if (instruction.Rd != 0)
                    _sb.AppendLine($"{I2}{Lo(instruction.Rd)} = 0x{link:X8}ull;");

                Delay(delay, address, I2);
                _sb.AppendLine($"{I2}ps2_call(c, dest);");
            }
            else if (mnemonic == "JAL")
            {
                instruction.TryGetBranchTarget(address, out uint target);

                _sb.AppendLine($"{I2}{Lo(31)} = 0x{link:X8}ull;");
                Delay(delay, address, I2);
                _sb.AppendLine($"{I2}{CallTo(target)}");
            }
            else if (mnemonic == "J")
            {
                instruction.TryGetBranchTarget(address, out uint target);

                Delay(delay, address, I2);
                _sb.AppendLine($"{I2}{JumpTo(target, start, end)}");
            }
            else
            {
                string? condition = Condition(instruction);
                instruction.TryGetBranchTarget(address, out uint target);
                bool likely = instruction.IsLikelyBranch;

                // A condicao e avaliada antes do delay slot, que pode
                // alterar os registradores comparados.
                if (condition == null)
                {
                    _sb.AppendLine($"{I2}bool take = false;");
                    Unsupported(instruction, address, I2);
                }
                else
                {
                    _sb.AppendLine($"{I2}bool take = {condition};");
                }

                if (instruction.IsBranchAndLink)
                {
                    _sb.AppendLine($"{I2}{Lo(31)} = 0x{link:X8}ull;");

                    if (likely)
                    {
                        _sb.AppendLine($"{I2}if (take)");
                        _sb.AppendLine($"{I2}{{");
                        Delay(delay, address, I2 + "    ");
                        _sb.AppendLine($"{I2}}}");
                    }
                    else
                    {
                        Delay(delay, address, I2);
                    }

                    _sb.AppendLine($"{I2}if (take) {CallTo(target)}");
                }
                else if (likely)
                {
                    // Branch likely: o delay slot so executa se desviar.
                    _sb.AppendLine($"{I2}if (take)");
                    _sb.AppendLine($"{I2}{{");
                    Delay(delay, address, I2 + "    ");
                    _sb.AppendLine($"{I2}    {JumpTo(target, start, end)}");
                    _sb.AppendLine($"{I2}}}");
                }
                else
                {
                    Delay(delay, address, I2);
                    _sb.AppendLine($"{I2}if (take) {JumpTo(target, start, end)}");
                }
            }

            _sb.AppendLine($"{I1}}}");
        }
    }
}
