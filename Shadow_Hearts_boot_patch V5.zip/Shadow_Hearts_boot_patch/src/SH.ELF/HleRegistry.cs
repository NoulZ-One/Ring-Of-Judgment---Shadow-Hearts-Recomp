using System.Text.RegularExpressions;

namespace SH.ELF;

// Funcoes do SDK/biblioteca que o runtime substitui por codigo nativo (HLE).
// A chave e o nome do simbolo no ELF; o valor e o corpo da funcao em C++, com
// acesso a `Ctx& c` (registradores do EE em c.r[...]) e ao runtime do ps2rt.h
// (mrd/mwr, ps2_call...). Registradores: a0..a3 = c.r[4..7].lo, retorno em c.r[2].lo.
// O gerador nao emite o corpo recompilado dessas funcoes: a tabela e as chamadas
// diretas apontam para hle_<nome>, escrito em ps2_hle.cpp.
public static class Hle
{
    public static readonly IReadOnlyDictionary<string, string> Functions =
        new Dictionary<string, string>
        {
            // libkernel: instala patches no kernel do console (SetSyscall, Copy para
            // 0x80076000 e arredores). O runtime implementa as syscalls nativamente.
            ["_InitSys"] = "    // nada a fazer: o kernel e o proprio runtime\n"
        };

    public static bool Contains(string symbolName) => Functions.ContainsKey(symbolName);

    public static string HostName(string symbolName) =>
        "hle_" + Regex.Replace(symbolName, "[^A-Za-z0-9_]", "_");
}
