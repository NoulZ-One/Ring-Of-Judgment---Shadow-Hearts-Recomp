using System.Text.RegularExpressions;

namespace SH.ELF;

// Funcoes do SDK/biblioteca que o runtime substitui por codigo nativo (HLE).
// A chave e o nome do simbolo no ELF; o valor e o corpo da funcao em C++, com
// acesso a `Ctx& c` (registradores do EE em c.r[...]) e ao runtime do ps2rt.h
// (mrd/mwr, ps2_call, ps2_cstr...). Registradores: a0..a3 = c.r[4..7].lo,
// retorno em c.r[2].lo. O gerador nao emite o corpo recompilado dessas funcoes:
// a tabela e as chamadas diretas apontam para hle_<nome>, escrito em ps2_hle.cpp.
// Nomes que nao existem no ELF sao ignorados.
public static class Hle
{
    // Camada SIF/RPC do SDK: o runtime nao emula o IOP. Se o jogo chegar nelas, o
    // programa para dizendo qual foi, em vez de executar a versao recompilada
    // (que esperaria para sempre por uma resposta do IOP).
    private static readonly string[] Pending =
    {
        "sceSifBindRpc", "sceSifCallRpc", "sceSifCheckStatRpc", "sceSifSetRpcQueue",
        "sceSifRegisterRpc", "sceSifRemoveRpc", "sceSifRemoveRpcQueue",
        "sceSifGetNextRequest", "sceSifExecRequest", "sceSifRpcLoop", "sceSifGetOtherData",
        "sceSifAddCmdHandler", "sceSifRemoveCmdHandler", "sceSifSendCmd",
        "sceSifSetCmdBuffer", "sceSifSetSysCmdBuffer",
        "sceSifInitIopHeap", "sceSifAllocIopHeap", "sceSifFreeIopHeap",
        "sceSifLoadElf", "sceSifLoadElfPart", "sceSifLoadFileReset", "sceSifLoadMemory"
    };

    // Atencao: os campos estaticos iniciam na ordem em que aparecem; Pending vem antes
    // de Functions porque Build() usa Pending.
    public static readonly IReadOnlyDictionary<string, string> Functions = Build();

    private static Dictionary<string, string> Build()
    {
        Dictionary<string, string> d = new()
        {
            // libkernel: instala patches no kernel do console (SetSyscall, Copy para
            // 0x80076000 e arredores). O runtime implementa as syscalls nativamente.
            ["_InitSys"] = "    // nada a fazer: o kernel e o proprio runtime",

            // Versoes "i" (para interrupcoes) do libkernel: usam syscalls instaladas pelo
            // _InitSys. Aqui chamam direto a syscall equivalente do runtime.
            ["iWakeupThread"] = "    c.r[3].lo = (uint64_t)(int64_t)-52;\n    ps2_syscall(c);",
            ["iSuspendThread"] = "    c.r[3].lo = (uint64_t)(int64_t)-56;\n    ps2_syscall(c);",
            ["iRotateThreadReadyQueue"] = "    c.r[3].lo = (uint64_t)(int64_t)-44;\n    ps2_syscall(c);",

            // SIF/IOP: inicializacao e carga de modulos. Nao ha IOP: tudo "da certo" e os
            // servicos (disco, controle, memory card, som) viram versoes nativas da API.
            ["sceSifInitRpc"] = "    c.r[2].lo = 0;",
            ["sceSifExitRpc"] = "    c.r[2].lo = 0;",
            ["sceSifInitCmd"] = "    c.r[2].lo = 0;",
            ["sceSifExitCmd"] = "    c.r[2].lo = 0;",
            ["sceSifSyncIop"] = "    c.r[2].lo = 1;",
            ["sceSifWriteBackDCache"] = "    // cache: nada a fazer",
            ["sceSifStartModule"] = "    if (c.r[7].lo != 0) mwr<uint32_t>(c, (uint32_t)c.r[7].lo, 0);\n    c.r[2].lo = 0;",
            ["sceSifStopModule"] = "    if (c.r[7].lo != 0) mwr<uint32_t>(c, (uint32_t)c.r[7].lo, 0);\n    c.r[2].lo = 0;",
            ["sceSifUnloadModule"] = "    c.r[2].lo = 0;",

            ["sceSifRebootIop"] = """
                    char name[256];
                    std::fprintf(stderr, "  sceSifRebootIop(\"%s\")\n", ps2_cstr(c, (uint32_t)c.r[4].lo, name, sizeof(name)));
                    c.r[2].lo = 1;
                """,

            // sceSifLoadModule(arquivo, tamanho_args, args): devolve o id do modulo
            ["sceSifLoadModule"] = """
                    char name[256];
                    uint32_t id = ps2_alloc_id();
                    std::fprintf(stderr, "  sceSifLoadModule(\"%s\") -> modulo %u\n", ps2_cstr(c, (uint32_t)c.r[4].lo, name, sizeof(name)), id);
                    c.r[2].lo = id;
                """,

            // sceSifLoadStartModule(arquivo, tamanho_args, args, resultado)
            ["sceSifLoadStartModule"] = """
                    char name[256];
                    uint32_t id = ps2_alloc_id();
                    std::fprintf(stderr, "  sceSifLoadStartModule(\"%s\") -> modulo %u\n", ps2_cstr(c, (uint32_t)c.r[4].lo, name, sizeof(name)), id);
                    if (c.r[7].lo != 0) mwr<uint32_t>(c, (uint32_t)c.r[7].lo, 0);
                    c.r[2].lo = id;
                """
        };

        foreach (string name in Pending)
            d.TryAdd(name, $"    ps2_hle_unimplemented(c, \"{name}\");");

        return d;
    }

    public static bool Contains(string symbolName) => Functions.ContainsKey(symbolName);

    public static string HostName(string symbolName) =>
        "hle_" + Regex.Replace(symbolName, "[^A-Za-z0-9_]", "_");
}
