using SH.ELF;

// Gera o C++ de uma funcao e grava em .\out (ps2rt.h + a funcao).
internal static class EmitDemo
{
    public static void Run(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        string functionName)
    {
        Console.WriteLine();
        Console.WriteLine($"=== Gerador de C++: {functionName} ===");

        List<ElfSymbol> functions = allFunctions
            .Where(f => f.Size >= 4 && f.Name.Length > 0)
            .ToList();

        ElfSymbol? function = functions
            .Where(f => f.Name == functionName)
            .OrderByDescending(f => f.Size)
            .FirstOrDefault();

        if (function == null)
        {
            Console.WriteLine("Funcao nao encontrada.");
            return;
        }

        Dictionary<uint, string> names = functions
            .GroupBy(f => f.Address)
            .ToDictionary(g => g.Key, g => g.First().Name);

        MipsCppEmitter.Result result =
            MipsCppEmitter.EmitFunction(image, function, names);

        string directory = Path.Combine(Directory.GetCurrentDirectory(), "out");

        Directory.CreateDirectory(directory);

        File.WriteAllText(
            Path.Combine(directory, "ps2rt.h"),
            MipsCppEmitter.RuntimeHeader);

        File.WriteAllText(
            Path.Combine(directory, MipsCppEmitter.FunctionName(function) + ".cpp"),
            result.Code);

        Console.WriteLine(result.Code);
        Console.WriteLine(
            $"Instrucoes: {result.Instructions}, sem suporte: {result.Unsupported}");
        Console.WriteLine($"Arquivos em: {directory}");
    }

    // Roda o gerador em todas as funcoes (sem gravar nada) e conta o que
    // ainda nao tem suporte: e a lista de pendencias do recompilador.
    public static void Coverage(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions)
    {
        Console.WriteLine();
        Console.WriteLine("=== Cobertura do gerador de C++ (todas as funcoes) ===");

        List<ElfSymbol> functions = allFunctions
            .Where(f => f.Size >= 4 && f.Name.Length > 0)
            .GroupBy(f => f.Address)
            .Select(g => g.OrderByDescending(f => f.Size).First())
            .OrderBy(f => f.Address)
            .ToList();

        long instructions = 0;
        long unsupported = 0;
        int cleanFunctions = 0;
        int failed = 0;
        Dictionary<string, int> byMnemonic = new();

        foreach (ElfSymbol function in functions)
        {
            MipsCppEmitter.Result result;

            try
            {
                result = MipsCppEmitter.EmitFunction(image, function);
            }
            catch (Exception ex) when (
                ex is ArgumentOutOfRangeException or InvalidDataException)
            {
                failed++;
                continue;
            }

            instructions += result.Instructions;
            unsupported += result.Unsupported;

            if (result.Unsupported == 0)
                cleanFunctions++;

            foreach (KeyValuePair<string, int> entry in result.UnsupportedByMnemonic)
            {
                byMnemonic[entry.Key] =
                    byMnemonic.GetValueOrDefault(entry.Key) + entry.Value;
            }
        }

        Console.WriteLine($"Funcoes: {functions.Count} (falharam ao gerar: {failed})");
        Console.WriteLine($"Funcoes 100% suportadas: {cleanFunctions}");
        Console.WriteLine($"Instrucoes: {instructions}");
        Console.WriteLine(
            $"Sem suporte: {unsupported} ({100.0 * unsupported / Math.Max(1, instructions):F1}%)");

        foreach (KeyValuePair<string, int> entry in byMnemonic
                     .OrderByDescending(e => e.Value)
                     .Take(30))
        {
            Console.WriteLine($"  {entry.Value,8}  {entry.Key}");
        }
    }
}

