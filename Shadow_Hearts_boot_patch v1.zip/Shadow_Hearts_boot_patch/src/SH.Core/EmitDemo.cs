using SH.ELF;

// Gera o C++ de uma funcao (Run), mede a cobertura do gerador em todo o
// executavel (Coverage) e analisa os JR de jump table (JumpTableReport).
internal static class EmitDemo
{
    // Resolvedor de jump tables a partir das relocacoes R_MIPS_32 do .relmain.
    public static JumpTableResolver CreateResolver(
        byte[] elf,
        IReadOnlyList<ElfSection> sections,
        ElfImage image)
    {
        ElfSection relocationSection =
            sections.First(s => s.Name == ".relmain");

        return new JumpTableResolver(
            image,
            ElfRelocations.ReadRel(elf, relocationSection));
    }

    private static List<ElfSymbol> Unique(IEnumerable<ElfSymbol> allFunctions)
    {
        return allFunctions
            .Where(f => f.Size >= 4 && f.Name.Length > 0)
            .GroupBy(f => f.Address)
            .Select(g => g.OrderByDescending(f => f.Size).First())
            .OrderBy(f => f.Address)
            .ToList();
    }

    public static void Run(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        string functionName,
        JumpTableResolver? jumpTables = null)
    {
        Console.WriteLine();
        Console.WriteLine($"=== Gerador de C++: {functionName} ===");

        List<ElfSymbol> functions = Unique(allFunctions);

        ElfSymbol? function = functions
            .Where(f => f.Name == functionName)
            .OrderByDescending(f => f.Size)
            .FirstOrDefault();

        if (function == null)
        {
            Console.WriteLine("Funcao nao encontrada.");
            return;
        }

        Dictionary<uint, string> names = functions
            .ToDictionary(f => f.Address, f => f.Name);

        MipsCppEmitter.Result result =
            MipsCppEmitter.EmitFunction(image, function, names, jumpTables);

        string directory = Path.Combine(Directory.GetCurrentDirectory(), "out");

        Directory.CreateDirectory(directory);

        File.WriteAllText(
            Path.Combine(directory, "ps2rt.h"),
            MipsCppEmitter.RuntimeHeader);

        File.WriteAllText(
            Path.Combine(directory, MipsCppEmitter.FunctionName(function) + ".cpp"),
            result.Code);

        Console.WriteLine(result.Code);
        Console.WriteLine(
            $"Instrucoes: {result.Instructions}, sem suporte: {result.Unsupported}");
        Console.WriteLine($"Arquivos em: {directory}");
    }

    // Roda o gerador em todas as funcoes (sem gravar nada) e conta o que
    // ainda nao tem suporte: e a lista de pendencias do recompilador.
    public static void Coverage(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        JumpTableResolver? jumpTables = null)
    {
        Console.WriteLine();
        Console.WriteLine("=== Cobertura do gerador de C++ (todas as funcoes) ===");

        List<ElfSymbol> functions = Unique(allFunctions);

        long instructions = 0;
        long unsupported = 0;
        int cleanFunctions = 0;
        int failed = 0;
        Dictionary<string, int> byMnemonic = new();

        foreach (ElfSymbol function in functions)
        {
            MipsCppEmitter.Result result;

            try
            {
                result = MipsCppEmitter.EmitFunction(image, function, null, jumpTables);
            }
            catch (Exception ex) when (
                ex is ArgumentOutOfRangeException or InvalidDataException)
            {
                failed++;
                continue;
            }

            instructions += result.Instructions;
            unsupported += result.Unsupported;

            if (result.Unsupported == 0)
                cleanFunctions++;

            foreach (KeyValuePair<string, int> entry in result.UnsupportedByMnemonic)
            {
                byMnemonic[entry.Key] =
                    byMnemonic.GetValueOrDefault(entry.Key) + entry.Value;
            }
        }

        Console.WriteLine($"Funcoes: {functions.Count} (falharam ao gerar: {failed})");
        Console.WriteLine($"Funcoes 100% suportadas: {cleanFunctions}");
        Console.WriteLine($"Instrucoes: {instructions}");
        Console.WriteLine(
            $"Sem suporte: {unsupported} ({100.0 * unsupported / Math.Max(1, instructions):F2}%)");

        foreach (KeyValuePair<string, int> entry in byMnemonic
                     .OrderByDescending(e => e.Value)
                     .Take(30))
        {
            Console.WriteLine($"  {entry.Value,8}  {entry.Key}");
        }
    }

    // Todos os JR que nao sao $ra: quantos viram jump table e por que os
    // outros nao. Mostra o contexto (instrucoes anteriores) dos primeiros
    // nao resolvidos, para ver que padroes faltam.
    public static void JumpTableReport(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        JumpTableResolver resolver)
    {
        Console.WriteLine();
        Console.WriteLine("=== JR em registrador que nao e $ra ===");
        Console.WriteLine($"Palavras com relocacao R_MIPS_32: {resolver.PointerCount}");

        int total = 0;
        int resolved = 0;
        int totalEntries = 0;
        int largest = 0;
        Dictionary<string, int> reasons = new();
        List<string> resolvedSamples = new();
        List<string> unresolvedSamples = new();

        foreach (ElfSymbol function in Unique(allFunctions))
        {
            int count = (int)(function.Size / 4);
            uint end = function.Address + (uint)(count * 4);

            MipsInstruction[] code = new MipsInstruction[count];

            for (int i = 0; i < count; i++)
            {
                code[i] = MipsDecoder.Decode(
                    image.ReadUInt32(function.Address + (uint)(i * 4)));
            }

            for (int i = 0; i < count; i++)
            {
                if (code[i].Mnemonic != "JR" || code[i].Rs == 31)
                    continue;

                total++;

                uint address = function.Address + (uint)(i * 4);

                if (resolver.TryResolve(
                        code, i, function.Address, end,
                        out JumpTableResolver.Table? table, out string reason) &&
                    table != null)
                {
                    resolved++;
                    totalEntries += table.Targets.Count;
                    largest = Math.Max(largest, table.Targets.Count);

                    if (resolvedSamples.Count < 8)
                    {
                        resolvedSamples.Add(
                            $"  0x{address:X8}  tabela 0x{table.TableAddress:X8}  " +
                            $"{table.Targets.Count} destinos (limite {(table.DeclaredEntries == int.MaxValue ? "?" : table.DeclaredEntries.ToString())})  {function.Name}");
                    }

                    continue;
                }

                reasons[reason] = reasons.GetValueOrDefault(reason) + 1;

                if (unresolvedSamples.Count < 14)
                {
                    unresolvedSamples.Add(
                        $"  0x{address:X8}  {function.Name}  [{reason}]");

                    int from = Math.Max(0, i - 8);

                    for (int k = from; k <= i; k++)
                    {
                        uint a = function.Address + (uint)(k * 4);

                        unresolvedSamples.Add(
                            $"      0x{a:X8}  {code[k].Format(a)}");
                    }
                }
            }
        }

        Console.WriteLine($"Total: {total}");
        Console.WriteLine($"Resolvidos como jump table: {resolved} (entradas: {totalEntries}, maior: {largest})");
        Console.WriteLine($"Nao resolvidos: {total - resolved}");

        foreach (KeyValuePair<string, int> entry in reasons.OrderByDescending(r => r.Value))
            Console.WriteLine($"  {entry.Value,5}  {entry.Key}");

        Console.WriteLine("Exemplos resolvidos:");

        foreach (string line in resolvedSamples)
            Console.WriteLine(line);

        Console.WriteLine("Exemplos nao resolvidos:");

        foreach (string line in unresolvedSamples)
            Console.WriteLine(line);
    }
}
