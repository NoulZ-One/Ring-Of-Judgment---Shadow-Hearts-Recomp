#include "ps2rt.h"

// memclr  0x00201708  (52 bytes)
void f_00201708_memclr(Ctx& c)
{
    // 0x00201708  BEQ $a1, $zero, 0x00201734
    {
        bool take = c.r[5].lo == c.r[0].lo;
        // 0x0020170C  ADDIU $v0, $a1, -0x1
        c.r[2].lo = S32((uint32_t)c.r[5].lo + 0xFFFFFFFFu);
        if (take) goto L_00201734;
    }
    // 0x00201710  ADDIU $v1, $zero, -0x1
    c.r[3].lo = S32((uint32_t)c.r[0].lo + 0xFFFFFFFFu);
    // 0x00201714  NOP
L_00201718:
    // 0x00201718  SB $zero, 0($a0)
    mwr<uint8_t>(c, (uint32_t)c.r[4].lo + 0x0u, (uint8_t)c.r[0].lo);
    // 0x0020171C  ADDIU $v0, $v0, -0x1
    c.r[2].lo = S32((uint32_t)c.r[2].lo + 0xFFFFFFFFu);
    // 0x00201720  ADDIU $a0, $a0, 0x1
    c.r[4].lo = S32((uint32_t)c.r[4].lo + 0x1u);
    // 0x00201724  NOP
    // 0x00201728  NOP
    // 0x0020172C  BNE $v0, $v1, 0x00201718
    {
        bool take = c.r[2].lo != c.r[3].lo;
        // 0x00201730  NOP
        if (take) goto L_00201718;
    }
L_00201734:
    // 0x00201734  JR $ra
    {
        // 0x00201738  NOP
        return;
    }
}
