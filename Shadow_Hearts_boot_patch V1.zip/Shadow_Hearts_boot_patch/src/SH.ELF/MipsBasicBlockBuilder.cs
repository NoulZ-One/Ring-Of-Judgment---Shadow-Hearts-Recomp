namespace SH.ELF;

public sealed class MipsBasicBlockBuilder
{
    private readonly MipsInstructionReader _reader;

    private readonly Func<uint, uint?> _indirectCallResolver;

    public MipsBasicBlockBuilder(
        MipsInstructionReader reader,
        Func<uint, uint?> indirectCallResolver)
    {
        _reader = reader;
        _indirectCallResolver = indirectCallResolver;
    }

    public MipsBasicBlock Build(
        uint startAddress,
        int maxInstructions)
    {
        MipsBasicBlock block = new(startAddress);

        uint currentAddress = startAddress;
        bool ended = false;

        for (int i = 0; i < maxInstructions; i++)
        {
            if (!_reader.TryRead(currentAddress, out MipsInstruction? instruction))
            {
                block.IsInvalid = true;
                ended = true;
                break;
            }

            block.AddInstruction(instruction);

            // Desvios condicionais: BEQ/BNE/BLEZ/BGTZ, REGIMM, likely, BCx.
            if (instruction.IsConditionalBranch)
            {
                uint? target =
                    _reader.GetBranchTarget(currentAddress, instruction);

                if (instruction.IsBranchAndLink)
                    block.CallTarget = target;
                else
                    block.BranchTarget = target;

                block.IsBranchLikely = instruction.IsBranchLikely;

                AddDelaySlot(block, currentAddress);

                // "B label" (BEQ $zero,$zero) nunca cai para a próxima instrução.
                if (!instruction.IsAlwaysTaken)
                    block.FallthroughAddress = currentAddress + 8;

                ended = true;
                break;
            }

            switch (instruction.Mnemonic)
            {
                case "J":
                    block.BranchTarget =
                        _reader.GetBranchTarget(currentAddress, instruction);

                    AddDelaySlot(block, currentAddress);
                    ended = true;
                    break;

                case "JAL":
                    block.CallTarget =
                        _reader.GetBranchTarget(currentAddress, instruction);

                    block.FallthroughAddress = currentAddress + 8;

                    AddDelaySlot(block, currentAddress);
                    ended = true;
                    break;

                case "JR":
                    if (instruction.Rs == 31)
                        block.IsReturn = true;
                    else
                        block.IsIndirectJump = true;

                    AddDelaySlot(block, currentAddress);
                    ended = true;
                    break;

                case "JALR":
                    block.IsIndirectCall = true;

                    block.ResolvedIndirectCallTarget =
                        _indirectCallResolver(currentAddress);

                    block.FallthroughAddress = currentAddress + 8;

                    AddDelaySlot(block, currentAddress);
                    ended = true;
                    break;
            }

            if (ended)
                break;

            currentAddress += 4;
        }

        // O limite de instruções foi atingido sem encontrar o fim do bloco:
        // continua a análise a partir da próxima instrução.
        if (!ended)
        {
            block.WasInstructionLimitReached = true;
            block.FallthroughAddress = currentAddress;
        }

        return block;
    }

    private void AddDelaySlot(MipsBasicBlock block, uint branchAddress)
    {
        if (_reader.TryRead(branchAddress + 4, out MipsInstruction? delaySlot))
            block.AddInstruction(delaySlot);
        else
            block.IsInvalid = true;
    }
}
