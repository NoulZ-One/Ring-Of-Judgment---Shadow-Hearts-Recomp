namespace SH.ELF;

public sealed class MipsInstruction
{
    public uint Raw { get; }

    public byte Opcode { get; }

    public byte Rs { get; }

    public byte Rt { get; }

    public byte Rd { get; }

    public byte Shamt { get; }

    public byte Funct { get; }

    public ushort Immediate { get; }

    public short SignedImmediate { get; }

    public uint Target { get; }

    public string Mnemonic { get; }

    public string DebugInfo =>
        $"RAW=0x{Raw:X8} " +
        $"OP=0x{Opcode:X2} " +
        $"RS={Rs} " +
        $"RT={Rt} " +
        $"RD={Rd} " +
        $"SH={Shamt} " +
        $"FUNCT=0x{Funct:X2} " +
        $"IMM=0x{Immediate:X4}";

    public string RsName => MipsRegister.GetName(Rs);

    public string RtName => MipsRegister.GetName(Rt);

    public string RdName => MipsRegister.GetName(Rd);

    // Instruções COP1 (ponto flutuante) usam outros campos:
    //   ft = rt, fs = rd, fd = shamt.
    public string FtName => MipsFpuRegister.GetName(Rt);

    public string FsName => MipsFpuRegister.GetName(Rd);

    public string FdName => MipsFpuRegister.GetName(Shamt);

    // Nomes antigos mantidos como alias, já corrigidos.
    public string Cop1FtName => FtName;

    public string Cop1FsName => FsName;

    public string Cop1FdName => FdName;

    public bool IsUnknown => Mnemonic == "UNKNOWN";

    // Grupos reconhecidos, mas cuja sub-operação ainda não é decodificada.
    public bool IsGenericGroup =>
        Mnemonic is "COP0" or "COP2" or
        "MMI0" or "MMI1" or "MMI2" or "MMI3";

    // Desvios condicionais com offset de 16 bits (inclui likely, link e BCx).
    public bool IsConditionalBranch =>
        Mnemonic is
            "BEQ" or "BNE" or "BLEZ" or "BGTZ" or
            "BEQL" or "BNEL" or "BLEZL" or "BGTZL" or
            "BLTZ" or "BGEZ" or "BLTZL" or "BGEZL" or
            "BLTZAL" or "BGEZAL" or "BLTZALL" or "BGEZALL" or
            "BC0F" or "BC0T" or "BC0FL" or "BC0TL" or
            "BC1F" or "BC1T" or "BC1FL" or "BC1TL" or
            "BC2F" or "BC2T" or "BC2FL" or "BC2TL";

    // Branch-likely: o delay slot só executa quando o desvio é tomado.
    public bool IsBranchLikely =>
        Mnemonic is
            "BEQL" or "BNEL" or "BLEZL" or "BGTZL" or
            "BLTZL" or "BGEZL" or "BLTZALL" or "BGEZALL" or
            "BC0FL" or "BC0TL" or "BC1FL" or "BC1TL" or
            "BC2FL" or "BC2TL";

    // Desvio condicional que também grava o endereço de retorno em $ra.
    public bool IsBranchAndLink =>
        Mnemonic is "BLTZAL" or "BGEZAL" or "BLTZALL" or "BGEZALL";

    // Desvios que, na prática, são sempre tomados:
    //   B  label  = BEQ  $zero, $zero, label
    //   BGEZ $zero, label (condição sempre verdadeira)
    public bool IsAlwaysTaken =>
        ((Mnemonic is "BEQ" or "BEQL") && Rs == Rt) ||
        ((Mnemonic is "BGEZ" or "BGEZL") && Rs == 0);

    public string Assembly
    {
        get
        {
            return Mnemonic switch
            {
                "SLL" or "SRL" or "SRA" or
                "DSLL" or "DSRL" or "DSRA" or
                "DSLL32" or "DSRL32" or "DSRA32" =>
                    $"{Mnemonic} {RdName}, {RtName}, {Shamt}",

                "SLLV" or "SRLV" or "SRAV" or
                "DSLLV" or "DSRLV" or "DSRAV" =>
                    $"{Mnemonic} {RdName}, {RtName}, {RsName}",

                "LUI" =>
                    $"{Mnemonic} {RtName}, 0x{Immediate:X4}",

                "ADDI" or "ADDIU" or "DADDI" or "DADDIU" or
                "SLTI" or "SLTIU" =>
                    $"{Mnemonic} {RtName}, {RsName}, {SignedImmediate}",

                "ANDI" or "ORI" or "XORI" =>
                    $"{Mnemonic} {RtName}, {RsName}, 0x{Immediate:X4}",

                "ADD" or "ADDU" or "SUB" or "SUBU" or
                "DADD" or "DADDU" or "DSUB" or "DSUBU" or
                "AND" or "OR" or "XOR" or "NOR" or
                "SLT" or "SLTU" or "MOVZ" or "MOVN" =>
                    $"{Mnemonic} {RdName}, {RsName}, {RtName}",

                "MULT" or "MULTU" or "MULT1" or "MULTU1" =>
                    $"{Mnemonic} {RdName}, {RsName}, {RtName}",

                "DIV" or "DIVU" or "DIV1" or "DIVU1" =>
                    $"{Mnemonic} {RsName}, {RtName}",

                "MFHI" or "MFLO" or "MFHI1" or "MFLO1" =>
                    $"{Mnemonic} {RdName}",

                "MTHI" or "MTLO" or "MTHI1" or "MTLO1" =>
                    $"{Mnemonic} {RsName}",

                "JR" =>
                    $"{Mnemonic} {RsName}",

                "JALR" =>
                    $"{Mnemonic} {RdName}, {RsName}",

                "BEQ" or "BNE" or "BEQL" or "BNEL" =>
                    $"{Mnemonic} {RsName}, {RtName}, {SignedImmediate}",

                "BLEZ" or "BGTZ" or "BLEZL" or "BGTZL" or
                "BLTZ" or "BGEZ" or "BLTZL" or "BGEZL" or
                "BLTZAL" or "BGEZAL" or "BLTZALL" or "BGEZALL" =>
                    $"{Mnemonic} {RsName}, {SignedImmediate}",

                "BC0F" or "BC0T" or "BC0FL" or "BC0TL" or
                "BC1F" or "BC1T" or "BC1FL" or "BC1TL" or
                "BC2F" or "BC2T" or "BC2FL" or "BC2TL" =>
                    $"{Mnemonic} {SignedImmediate}",

                "LB" or "LH" or "LWL" or "LW" or
                "LBU" or "LHU" or "LWR" or "LWU" or
                "LDL" or "LDR" or "LD" or "LQ" or
                "SB" or "SH" or "SWL" or "SW" or
                "SDL" or "SDR" or "SWR" or "SD" or "SQ" =>
                    $"{Mnemonic} {RtName}, {SignedImmediate}({RsName})",

                "LWC1" or "SWC1" =>
                    $"{Mnemonic} {FtName}, {SignedImmediate}({RsName})",

                "MFC1" or "MTC1" =>
                    $"{Mnemonic} {RtName}, {FsName}",

                "ADD.S" or "SUB.S" or "MUL.S" or "DIV.S" or
                "RSQRT.S" or "MAX.S" or "MIN.S" or
                "MADD.S" or "MSUB.S" =>
                    $"{Mnemonic} {FdName}, {FsName}, {FtName}",

                "SQRT.S" =>
                    $"{Mnemonic} {FdName}, {FtName}",

                "ABS.S" or "MOV.S" or "NEG.S" or
                "CVT.W.S" or "CVT.S.W" =>
                    $"{Mnemonic} {FdName}, {FsName}",

                "ADDA.S" or "SUBA.S" or "MULA.S" or
                "MADDA.S" or "MSUBA.S" or
                "C.F.S" or "C.EQ.S" or "C.LT.S" or "C.LE.S" =>
                    $"{Mnemonic} {FsName}, {FtName}",

                "MFC0" or "MTC0" =>
                    $"{Mnemonic} {RtName}, ${Rd}",

                _ =>
                    Mnemonic
            };
        }
    }

    public MipsInstruction(
        uint raw,
        byte opcode,
        byte rs,
        byte rt,
        byte rd,
        byte shamt,
        byte funct,
        ushort immediate,
        short signedImmediate,
        uint target,
        string mnemonic)
    {
        Raw = raw;

        Opcode = opcode;

        Rs = rs;
        Rt = rt;
        Rd = rd;

        Shamt = shamt;
        Funct = funct;

        Immediate = immediate;
        SignedImmediate = signedImmediate;

        Target = target;

        Mnemonic = mnemonic;
    }
}
