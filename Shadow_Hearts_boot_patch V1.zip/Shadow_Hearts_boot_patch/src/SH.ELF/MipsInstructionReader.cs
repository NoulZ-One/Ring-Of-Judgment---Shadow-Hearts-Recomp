using System.Diagnostics.CodeAnalysis;

namespace SH.ELF;

public sealed class MipsInstructionReader
{
    private readonly ElfImage _image;

    public MipsInstructionReader(ElfImage image)
    {
        _image = image;
    }

    public MipsInstruction Read(uint virtualAddress)
    {
        if ((virtualAddress & 3) != 0)
            throw new ArgumentException(
                $"Endereço 0x{virtualAddress:X8} não está alinhado a 4 bytes.",
                nameof(virtualAddress));

        // Não exige flag de execução: alguns executáveis PS2 usam um único
        // segmento RWX. Só garante que o endereço está carregado.
        if (!_image.TryReadUInt32(virtualAddress, out uint raw))
            throw new ArgumentOutOfRangeException(
                nameof(virtualAddress),
                $"0x{virtualAddress:X8} está fora das regiões carregadas.");

        return MipsDecoder.Decode(raw);
    }

    // Versão que não lança exceção: devolve false se o endereço estiver
    // desalinhado ou fora das regiões carregadas.
    public bool TryRead(
        uint virtualAddress,
        [NotNullWhen(true)] out MipsInstruction? instruction)
    {
        instruction = null;

        if ((virtualAddress & 3) != 0)
            return false;
        
        ElfImage.Region? region = _image.FindRegion(virtualAddress, 4);

        if (region == null ||
            virtualAddress - region.VirtualAddress + 4 > region.FileSize)
            return false;

        if (!_image.TryReadUInt32(virtualAddress, out uint raw))
            return false;

        instruction = MipsDecoder.Decode(raw);
        return true;
    }

    public uint? GetBranchTarget(
        uint instructionAddress,
        MipsInstruction instruction)
    {
        if (instruction.Mnemonic == "J" ||
            instruction.Mnemonic == "JAL")
        {
            uint nextInstruction = instructionAddress + 4;

            return (nextInstruction & 0xF0000000) |
                   (instruction.Target << 2);
        }

        if (!instruction.IsConditionalBranch)
            return null;

        int offset = instruction.SignedImmediate * 4;

        return unchecked(
            (uint)((int)(instructionAddress + 4) + offset));
    }
}
