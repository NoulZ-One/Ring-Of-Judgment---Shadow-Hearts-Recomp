using System.Text;
using SH.ELF;

// Gera o C++ de uma funcao (Run), mede a cobertura do gerador em todo o
// executavel (Coverage) e analisa os JR de jump table (JumpTableReport).
internal static class EmitDemo
{
    // Resolvedor de jump tables a partir das relocacoes R_MIPS_32 do .relmain.
    public static JumpTableResolver CreateResolver(
        byte[] elf,
        IReadOnlyList<ElfSection> sections,
        ElfImage image)
    {
        ElfSection relocationSection =
            sections.First(s => s.Name == ".relmain");

        return new JumpTableResolver(
            image,
            ElfRelocations.ReadRel(elf, relocationSection));
    }

    private static List<ElfSymbol> Unique(IEnumerable<ElfSymbol> allFunctions)
    {
        return allFunctions
            .Where(f => f.Size >= 4 && f.Name.Length > 0)
            .GroupBy(f => f.Address)
            .Select(g => g.OrderByDescending(f => f.Size).First())
            .OrderBy(f => f.Address)
            .ToList();
    }

    // Gera o C++ do executavel inteiro em .\out: ps2rt.h, ps2_functions.h (prototipos),
    // ps2_functions_NNN.cpp (corpos, em lotes), ps2_table.cpp (endereco -> funcao),
    // ps2_runtime.cpp (runtime minimo) e ps2_selftest.cpp (chama o memclr pela tabela).
    // Sem comentarios por padrao: com eles o resultado passa de 70 MB.
    public static void EmitAll(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        JumpTableResolver? jumpTables,
        string directory,
        bool comments = false)
    {
        Console.WriteLine();
        Console.WriteLine("=== Gerando C++ de todas as funcoes ===");

        List<ElfSymbol> functions = Unique(allFunctions);

        Directory.CreateDirectory(directory);

        Dictionary<uint, string> directCalls = functions
            .ToDictionary(f => f.Address, f => MipsCppEmitter.FunctionName(f));

        const int ShardChars = 6_000_000;

        StringBuilder shard = new();
        int shardCount = 0;
        long totalChars = 0;
        long unsupported = 0;
        long dispatched = 0;
        int failed = 0;
        List<ElfSymbol> emitted = new();

        void Flush()
        {
            if (shard.Length == 0)
                return;

            File.WriteAllText(
                Path.Combine(directory, $"ps2_functions_{shardCount:D3}.cpp"),
                "#include \"ps2_functions.h\"\n\n" + shard);

            shardCount++;
            shard.Clear();
        }

        foreach (ElfSymbol function in functions)
        {
            MipsCppEmitter.Result result;

            try
            {
                result = MipsCppEmitter.EmitFunction(
                    image, function, null, jumpTables, directCalls,
                    comments, includeHeader: false);
            }
            catch (Exception ex) when (
                ex is ArgumentOutOfRangeException or InvalidDataException)
            {
                failed++;
                continue;
            }

            emitted.Add(function);
            unsupported += result.Unsupported;
            dispatched += result.RuntimeDispatches;
            totalChars += result.Code.Length;

            shard.AppendLine(result.Code);

            if (shard.Length >= ShardChars)
                Flush();
        }

        Flush();

        // prototipos e tabela de despacho
        StringBuilder header = new();
        header.AppendLine("#pragma once");
        header.AppendLine("#include \"ps2rt.h\"");
        header.AppendLine();
        header.AppendLine("struct Ps2FuncEntry { uint32_t address; void (*fn)(Ctx&); };");
        header.AppendLine("extern const Ps2FuncEntry ps2_function_table[];");
        header.AppendLine("extern const unsigned ps2_function_count;");
        header.AppendLine();

        StringBuilder table = new();
        table.AppendLine("#include \"ps2_functions.h\"");
        table.AppendLine();
        table.AppendLine("const Ps2FuncEntry ps2_function_table[] =");
        table.AppendLine("{");

        foreach (ElfSymbol function in emitted)
        {
            string name = MipsCppEmitter.FunctionName(function);

            header.AppendLine($"void {name}(Ctx& c);");
            table.AppendLine($"    {{ 0x{function.Address:X8}u, {name} }},");
        }

        table.AppendLine("};");
        table.AppendLine(
            "const unsigned ps2_function_count = sizeof(ps2_function_table) / sizeof(ps2_function_table[0]);");

        File.WriteAllText(Path.Combine(directory, "ps2rt.h"), MipsCppEmitter.RuntimeHeader);
        File.WriteAllText(Path.Combine(directory, "ps2_functions.h"), header.ToString());
        File.WriteAllText(Path.Combine(directory, "ps2_table.cpp"), table.ToString());
        File.WriteAllText(Path.Combine(directory, "ps2_runtime.cpp"), MipsCppEmitter.RuntimeSource);

        ElfSymbol? memclr = emitted.FirstOrDefault(f => f.Name == "memclr");

        if (memclr != null)
        {
            File.WriteAllText(
                Path.Combine(directory, "ps2_selftest.cpp"),
                SelfTestSource(memclr.Address));
        }

        Console.WriteLine($"Funcoes geradas: {emitted.Count} (falharam: {failed})");
        Console.WriteLine($"Lotes: {shardCount}, texto: {totalChars / 1_000_000.0:F1} MB");
        Console.WriteLine($"Instrucoes sem suporte (viram parada em tempo de execucao): {unsupported}");
        Console.WriteLine($"JR indireto resolvido em tempo de execucao: {dispatched}");
        Console.WriteLine($"Arquivos em: {directory}");
        Console.WriteLine("Para compilar (exemplo): g++ -std=c++17 -O0 -c *.cpp  (um .o por arquivo)");
        Console.WriteLine("Teste rapido: compile tudo e linke com ps2_selftest.cpp (exige o memclr).");
    }

    private static string SelfTestSource(uint memclrAddress)
    {
        return
            "#include \"ps2_functions.h\"\n" +
            "#include <cstdio>\n\n" +
            "static uint8_t ram[32u * 1024 * 1024];\n\n" +
            "int main()\n" +
            "{\n" +
            "    Ctx c{};\n" +
            "    c.mem = ram;\n" +
            "    vu0_init(c);\n\n" +
            "    for (int i = 0; i < 64; i++) ram[0x00300000 + i] = 0xAA;\n" +
            "    c.r[4].lo = 0x00300000;\n" +
            "    c.r[5].lo = 32;\n" +
            $"    ps2_call(c, 0x{memclrAddress:X8}u);\n\n" +
            "    int zeros = 0;\n" +
            "    for (int i = 0; i < 64; i++) zeros += ram[0x00300000 + i] == 0;\n" +
            "    std::printf(\"memclr pela tabela: %d bytes zerados (esperado 32)\\n\", zeros);\n" +
            "    return zeros == 32 ? 0 : 1;\n" +
            "}\n";
    }

    public static void Run(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        string functionName,
        JumpTableResolver? jumpTables = null)
    {
        Console.WriteLine();
        Console.WriteLine($"=== Gerador de C++: {functionName} ===");

        List<ElfSymbol> functions = Unique(allFunctions);

        ElfSymbol? function = functions
            .Where(f => f.Name == functionName)
            .OrderByDescending(f => f.Size)
            .FirstOrDefault();

        if (function == null)
        {
            Console.WriteLine("Funcao nao encontrada.");
            return;
        }

        Dictionary<uint, string> names = functions
            .ToDictionary(f => f.Address, f => f.Name);

        MipsCppEmitter.Result result =
            MipsCppEmitter.EmitFunction(image, function, names, jumpTables);

        string directory = Path.Combine(Directory.GetCurrentDirectory(), "out");

        Directory.CreateDirectory(directory);

        File.WriteAllText(
            Path.Combine(directory, "ps2rt.h"),
            MipsCppEmitter.RuntimeHeader);

        File.WriteAllText(
            Path.Combine(directory, MipsCppEmitter.FunctionName(function) + ".cpp"),
            result.Code);

        Console.WriteLine(result.Code);
        Console.WriteLine(
            $"Instrucoes: {result.Instructions}, sem suporte: {result.Unsupported}");
        Console.WriteLine($"Arquivos em: {directory}");
    }

    // Roda o gerador em todas as funcoes (sem gravar nada) e conta o que
    // ainda nao tem suporte: e a lista de pendencias do recompilador.
    public static void Coverage(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        JumpTableResolver? jumpTables = null)
    {
        Console.WriteLine();
        Console.WriteLine("=== Cobertura do gerador de C++ (todas as funcoes) ===");

        List<ElfSymbol> functions = Unique(allFunctions);

        long instructions = 0;
        long unsupported = 0;
        long dispatched = 0;
        int cleanFunctions = 0;
        int failed = 0;
        Dictionary<string, int> byMnemonic = new();

        foreach (ElfSymbol function in functions)
        {
            MipsCppEmitter.Result result;

            try
            {
                result = MipsCppEmitter.EmitFunction(image, function, null, jumpTables);
            }
            catch (Exception ex) when (
                ex is ArgumentOutOfRangeException or InvalidDataException)
            {
                failed++;
                continue;
            }

            instructions += result.Instructions;
            unsupported += result.Unsupported;
            dispatched += result.RuntimeDispatches;

            if (result.Unsupported == 0)
                cleanFunctions++;

            foreach (KeyValuePair<string, int> entry in result.UnsupportedByMnemonic)
            {
                byMnemonic[entry.Key] =
                    byMnemonic.GetValueOrDefault(entry.Key) + entry.Value;
            }
        }

        Console.WriteLine($"Funcoes: {functions.Count} (falharam ao gerar: {failed})");
        Console.WriteLine($"Funcoes 100% suportadas: {cleanFunctions}");
        Console.WriteLine($"Instrucoes: {instructions}");
        Console.WriteLine(
            $"Sem suporte: {unsupported} ({100.0 * unsupported / Math.Max(1, instructions):F2}%)");
        Console.WriteLine($"JR indireto resolvido em tempo de execucao: {dispatched}");

        foreach (KeyValuePair<string, int> entry in byMnemonic
                     .OrderByDescending(e => e.Value)
                     .Take(30))
        {
            Console.WriteLine($"  {entry.Value,8}  {entry.Key}");
        }
    }

    // Todos os JR que nao sao $ra: quantos viram jump table e por que os
    // outros nao. Mostra o contexto (instrucoes anteriores) dos primeiros
    // nao resolvidos, para ver que padroes faltam.
    public static void JumpTableReport(
        ElfImage image,
        IEnumerable<ElfSymbol> allFunctions,
        JumpTableResolver resolver)
    {
        Console.WriteLine();
        Console.WriteLine("=== JR em registrador que nao e $ra ===");
        Console.WriteLine($"Palavras com relocacao R_MIPS_32: {resolver.PointerCount}");

        int total = 0;
        int resolved = 0;
        int totalEntries = 0;
        int largest = 0;
        Dictionary<string, int> reasons = new();
        List<string> resolvedSamples = new();
        List<string> unresolvedSamples = new();

        foreach (ElfSymbol function in Unique(allFunctions))
        {
            int count = (int)(function.Size / 4);
            uint end = function.Address + (uint)(count * 4);

            MipsInstruction[] code = new MipsInstruction[count];

            for (int i = 0; i < count; i++)
            {
                code[i] = MipsDecoder.Decode(
                    image.ReadUInt32(function.Address + (uint)(i * 4)));
            }

            for (int i = 0; i < count; i++)
            {
                if (code[i].Mnemonic != "JR" || code[i].Rs == 31)
                    continue;

                total++;

                uint address = function.Address + (uint)(i * 4);

                if (resolver.TryResolve(
                        code, i, function.Address, end,
                        out JumpTableResolver.Table? table, out string reason) &&
                    table != null)
                {
                    resolved++;
                    totalEntries += table.Targets.Count;
                    largest = Math.Max(largest, table.Targets.Count);

                    if (resolvedSamples.Count < 8)
                    {
                        resolvedSamples.Add(
                            $"  0x{address:X8}  tabela 0x{table.TableAddress:X8}  " +
                            $"{table.Targets.Count} destinos (limite {(table.DeclaredEntries == int.MaxValue ? "?" : table.DeclaredEntries.ToString())})  {function.Name}");
                    }

                    continue;
                }

                reasons[reason] = reasons.GetValueOrDefault(reason) + 1;

                if (unresolvedSamples.Count < 14)
                {
                    unresolvedSamples.Add(
                        $"  0x{address:X8}  {function.Name}  [{reason}]");

                    int from = Math.Max(0, i - 8);

                    for (int k = from; k <= i; k++)
                    {
                        uint a = function.Address + (uint)(k * 4);

                        unresolvedSamples.Add(
                            $"      0x{a:X8}  {code[k].Format(a)}");
                    }
                }
            }
        }

        Console.WriteLine($"Total: {total}");
        Console.WriteLine($"Resolvidos como jump table: {resolved} (entradas: {totalEntries}, maior: {largest})");
        Console.WriteLine($"Nao resolvidos: {total - resolved}");

        foreach (KeyValuePair<string, int> entry in reasons.OrderByDescending(r => r.Value))
            Console.WriteLine($"  {entry.Value,5}  {entry.Key}");

        Console.WriteLine("Exemplos resolvidos:");

        foreach (string line in resolvedSamples)
            Console.WriteLine(line);

        Console.WriteLine("Exemplos nao resolvidos:");

        foreach (string line in unresolvedSamples)
            Console.WriteLine(line);
    }
}
