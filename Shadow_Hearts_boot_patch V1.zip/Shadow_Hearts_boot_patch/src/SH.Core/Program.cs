using SH.ELF;
using SH.ISO;

string? isoPath =
    args.Length > 0
        ? args[0]
        : Environment.GetEnvironmentVariable("SH_ISO");

if (string.IsNullOrWhiteSpace(isoPath) || !File.Exists(isoPath))
{
    Console.WriteLine("Uso: SH.Core <caminho-da-iso>");
    Console.WriteLine("(ou defina a variável de ambiente SH_ISO)");
    return 1;
}

static string FormatFlags(ElfImage.Region region) =>
    $"{(region.IsReadable ? 'R' : '-')}" +
    $"{(region.IsWritable ? 'W' : '-')}" +
    $"{(region.IsExecutable ? 'X' : '-')}";

try
{
    using IsoReader iso = new(isoPath);
    IsoFileSystem fs = new(iso);

    Console.WriteLine("=== Shadow Hearts Recompiler ===");
    Console.WriteLine();

    Console.WriteLine("=== Volume ISO-9660 ===");
    Console.WriteLine($"Volume:   {fs.Volume.VolumeIdentifier}");
    Console.WriteLine($"Setores:  {fs.Volume.VolumeSpaceSize}");
    Console.WriteLine($"Raiz:     setor {fs.Volume.RootDirectorySector}");
    Console.WriteLine();

    // 1) SYSTEM.CNF diz qual executável o PS2 carrega.
    Console.WriteLine("=== SYSTEM.CNF ===");

    SystemConfig config = fs.ReadSystemConfig();

    foreach (KeyValuePair<string, string> entry in config.Entries)
        Console.WriteLine($"{entry.Key,-8} = {entry.Value}");

    Console.WriteLine();

    if (config.BootPath == null)
    {
        Console.WriteLine("SYSTEM.CNF não tem BOOT2/BOOT.");
        return 1;
    }

    if (!config.IsPlayStation2Boot)
    {
        Console.WriteLine(
            $"Aviso: a chave é {config.BootKey}, não BOOT2. " +
            "Isso é um disco de PS1 e o executável não é um ELF.");
        return 1;
    }

    Console.WriteLine($"Executável de boot: {config.BootPath}");

    // 2) Localiza o arquivo na ISO.
    IsoDirectoryRecord? bootRecord = fs.Find(config.BootPath);

    if (bootRecord == null)
    {
        Console.WriteLine("Não encontrado na ISO. Conteúdo da raiz:");

        foreach (IsoDirectoryRecord record in fs.ListRoot())
            Console.WriteLine($"  {record.FileIdentifier}");

        return 1;
    }

    Console.WriteLine(
        $"Setor {bootRecord.ExtentLocation}, " +
        $"{bootRecord.DataLength} bytes");
    Console.WriteLine();

    // 3) Lê e carrega o ELF.
    byte[] elfBytes = fs.ReadFile(bootRecord);
    ElfImage image = ElfImage.Load(elfBytes);

    Console.WriteLine("=== ELF ===");
    Console.WriteLine($"Máquina:      {image.Header.Machine} (MIPS)");
    Console.WriteLine($"Tipo:         0x{image.Header.Type:X4}");
    Console.WriteLine($"Flags:        0x{image.Header.Flags:X8}");
    Console.WriteLine($"Entry point:  0x{image.EntryPoint:X8}");
    Console.WriteLine();

    Console.WriteLine("=== Regiões carregadas ===");

    foreach (ElfImage.Region region in image.Regions)
    {
        Console.WriteLine(
            $"0x{region.VirtualAddress:X8}-0x{region.EndAddress:X8}  " +
            $"{FormatFlags(region)}  " +
            $"arquivo={region.FileSize}  " +
            $"memória={region.Data.Length}  " +
            $"bss={region.Data.Length - region.FileSize}");
    }

    Console.WriteLine();
    Console.WriteLine("=== Primeiras instruções no entry point ===");

    MipsInstructionReader reader = new(image);

    uint address = image.EntryPoint;

    for (int i = 0; i < 16; i++)
    {
        if (image.FindRegion(address, 4) == null)
            break;

        MipsInstruction instruction = reader.Read(address);

        Console.WriteLine(
            $"0x{address:X8}  {instruction.Raw:X8}  {instruction.Assembly}");

        address += 4;
    }

    Console.WriteLine();
    Console.WriteLine("=== Descoberta de funções ===");

    MipsBasicBlockBuilder blockBuilder = new(reader, _ => null);
    MipsFunctionBuilder functionBuilder = new(blockBuilder);
    MipsProgramBuilder programBuilder = new(functionBuilder);
    MipsFunctionAnalyzer analyzer = new(reader);

    // Regiões de código; se nenhuma tiver a flag X (segmento único RWX), usa todas.
    List<ElfImage.Region> codeRegions =
        image.Regions.Where(r => r.IsExecutable).ToList();

    if (codeRegions.Count == 0)
        codeRegions = image.Regions.ToList();

    bool IsInCode(uint candidate) =>
        codeRegions.Any(r => candidate >= r.VirtualAddress &&
                             candidate < r.VirtualAddress + r.FileSize);

    // Sementes: entry point + todos os alvos de JAL encontrados por varredura linear.
    HashSet<uint> seeds = new() { image.EntryPoint };

    foreach (ElfImage.Region region in codeRegions)
    {
        if ((region.VirtualAddress & 3) != 0)
            continue;

        int words = (int)(region.FileSize / 4);

        foreach (uint target in analyzer.FindFunctionCalls(region.VirtualAddress, words))
        {
            if (IsInCode(target))
                seeds.Add(target);
        }
    }

    Console.WriteLine($"Sementes (entry + alvos de JAL): {seeds.Count}");

    MipsProgram program = programBuilder.Build(
        seeds.OrderBy(a => a),
        maxInstructionsPerBlock: 4096,
        maxBlocksPerFunction: 4096);

    HashSet<uint> seenInstructions = new();
    Dictionary<string, (int Count, uint Example)> unknownKinds = new();

    int totalBlocks = 0;
    int indirectCalls = 0;
    int indirectJumps = 0;
    int invalidBlocks = 0;
    int likelyBranches = 0;
    int unknownCount = 0;
    int genericCount = 0;
    int functionsWithoutReturn = 0;
    int functionsAtLimit = 0;
    
    Dictionary<string, int> genericKinds = new();
    

    foreach (MipsFunction function in program.Functions.Values)
    {
        if (!function.HasReturn)
            functionsWithoutReturn++;

        if (function.WasBlockLimitReached || function.WasInstructionLimitReached)
            functionsAtLimit++;

        foreach (MipsBasicBlock block in function.BasicBlocks)
        {
            totalBlocks++;

            if (block.IsIndirectCall)
                indirectCalls++;

            if (block.IsIndirectJump)
                indirectJumps++;

            if (block.IsInvalid)
                invalidBlocks++;

            if (block.IsBranchLikely)
                likelyBranches++;

            for (int i = 0; i < block.Instructions.Count; i++)
            {
                uint instructionAddress = block.StartAddress + (uint)(i * 4);

                if (!seenInstructions.Add(instructionAddress))
                    continue;

                MipsInstruction instruction = block.Instructions[i];

                if (instruction.IsGenericGroup)
                {
                    genericCount++;
                    genericKinds[instruction.Mnemonic] =
                        genericKinds.GetValueOrDefault(instruction.Mnemonic) + 1;
                }

                if (!instruction.IsUnknown)
                    continue;

                unknownCount++;

                string key = instruction.Opcode == 0
                    ? $"SPECIAL funct=0x{instruction.Funct:X2}"
                    : $"opcode=0x{instruction.Opcode:X2}";

                unknownKinds.TryGetValue(key, out var current);
                unknownKinds[key] = (current.Count + 1,
                    current.Count == 0 ? instructionAddress : current.Example);
            }
        }
    }

    Console.WriteLine($"Funções descobertas:        {program.Functions.Count}");
    Console.WriteLine($"Blocos básicos:             {totalBlocks}");
    Console.WriteLine($"Instruções alcançadas:      {seenInstructions.Count}");
    Console.WriteLine($"  UNKNOWN:                  {unknownCount}");
    Console.WriteLine($"  sem detalhe (COP0/2,MMI): {genericCount}");
    Console.WriteLine($"Chamadas indiretas (JALR):  {indirectCalls}");
    Console.WriteLine($"Saltos indiretos (JR):      {indirectJumps}");
    Console.WriteLine($"Branch-likely:              {likelyBranches}");
    Console.WriteLine($"Blocos inválidos:           {invalidBlocks}");
    Console.WriteLine($"Funções sem retorno:        {functionsWithoutReturn}");
    Console.WriteLine($"Funções que bateram limite: {functionsAtLimit}");

    Console.WriteLine();
    Console.WriteLine("=== Sem detalhe (por grupo) ===");

    foreach (var item in genericKinds.OrderByDescending(k => k.Value))
        Console.WriteLine($"{item.Key,-8} {item.Value}");

    Console.WriteLine();
    Console.WriteLine("=== Funções sem retorno ou que bateram limite ===");

    foreach (MipsFunction problem in program.Functions.Values.Where(fn =>
                 !fn.HasReturn ||
                 fn.WasBlockLimitReached ||
                 fn.WasInstructionLimitReached))
    {
        Console.WriteLine(
            $"0x{problem.StartAddress:X8}  blocos={problem.BasicBlocks.Count}  " +
            $"retorno={problem.HasReturn}  " +
            $"limite={problem.WasBlockLimitReached || problem.WasInstructionLimitReached}");
    }
    
    if (unknownKinds.Count > 0)
    {
        Console.WriteLine();
        Console.WriteLine("=== Instruções UNKNOWN mais frequentes ===");

        foreach (var kind in unknownKinds
                     .OrderByDescending(k => k.Value.Count)
                     .Take(15))
        {
            Console.WriteLine(
                $"{kind.Key,-22} x{kind.Value.Count,-6} " +
                $"ex.: 0x{kind.Value.Example:X8}");
        }
    }
    
        Console.WriteLine();
    Console.WriteLine("=== Varredura extra (prólogos e ponteiros de função) ===");

    int scanFileWords = image.Regions.Sum(item => (int)(item.FileSize / 4));

    MipsProgramStats scanStats = MipsProgramStats.From(program);
    MipsProgram scanProgram = program;
    HashSet<uint> scanSeeds = new(seeds);

    Console.WriteLine(
        $"Antes: {scanStats.Functions} funções, {scanStats.Instructions} instruções " +
        $"({100.0 * scanStats.Instructions / scanFileWords:F1}% do arquivo), " +
        $"UNKNOWN={scanStats.Unknown}, blocos inválidos={scanStats.InvalidBlocks}");

    for (int scanRound = 1; scanRound <= 3; scanRound++)
    {
        MipsProgramStats roundStats = scanStats;

        List<uint> scanPrologues = MipsFunctionScanner.FindPrologueCandidates(
            image, addr => roundStats.ReachedAddresses.Contains(addr));

        HashSet<uint> scanValid = new(scanProgram.Functions.Keys);
        scanValid.UnionWith(scanPrologues);

        PointerScanResult scanPointers = MipsFunctionScanner.FindFunctionPointers(
            image, addr => roundStats.ReachedAddresses.Contains(addr), scanValid);

        int pointersToKnown = scanPointers.Targets.Count(
            addr => scanProgram.Functions.ContainsKey(addr));

        HashSet<uint> newSeeds = new(scanPrologues);
        newSeeds.UnionWith(scanPointers.Targets);
        newSeeds.ExceptWith(scanSeeds);
        newSeeds.RemoveWhere(addr => scanProgram.Functions.ContainsKey(addr));

        Console.WriteLine(
            $"Rodada {scanRound}: prólogos={scanPrologues.Count}, " +
            $"palavras que apontam para função={scanPointers.PointerWords} " +
            $"(alvos distintos={scanPointers.Targets.Count}, já conhecidos={pointersToKnown}), " +
            $"novas sementes={newSeeds.Count}");

        if (newSeeds.Count == 0)
            break;

        if (scanRound == 1)
        {
            foreach (uint sample in newSeeds.OrderBy(addr => addr).Take(5))
            {
                Console.WriteLine($"  amostra 0x{sample:X8}:");

                for (int offset = 0; offset < 4; offset++)
                {
                    if (reader.TryRead(sample + (uint)(offset * 4),
                                       out MipsInstruction? sampleInstruction))
                        Console.WriteLine($"      {sampleInstruction.Assembly}");
                }
            }
        }

        scanSeeds.UnionWith(newSeeds);

        scanProgram = programBuilder.Build(
            scanSeeds.OrderBy(addr => addr),
            maxInstructionsPerBlock: 4096,
            maxBlocksPerFunction: 4096);

        scanStats = MipsProgramStats.From(scanProgram);

        Console.WriteLine(
            $"  -> {scanStats.Functions} funções, {scanStats.Instructions} instruções " +
            $"({100.0 * scanStats.Instructions / scanFileWords:F1}%), " +
            $"UNKNOWN={scanStats.Unknown}, blocos inválidos={scanStats.InvalidBlocks}, " +
            $"sem retorno={scanStats.WithoutReturn}");
    }
    Console.WriteLine();
    Console.WriteLine("=== Blocos inválidos e funções sem retorno (após varredura) ===");

    foreach (MipsFunction scanFunction in scanProgram.Functions.Values)
    {
        foreach (MipsBasicBlock scanBlock in scanFunction.BasicBlocks.Where(x => x.IsInvalid))
        {
            string last = scanBlock.Instructions.Count > 0
                ? scanBlock.Instructions[^1].Assembly
                : "(vazio)";

            Console.WriteLine(
                $"inválido: função 0x{scanFunction.StartAddress:X8}, " +
                $"bloco 0x{scanBlock.StartAddress:X8}, última: {last}");
        }

        if (!scanFunction.HasReturn)
            Console.WriteLine(
                $"sem retorno: 0x{scanFunction.StartAddress:X8} " +
                $"(blocos={scanFunction.BasicBlocks.Count})");
    }
    Console.WriteLine();
    Console.WriteLine("=== Conteúdo da raiz da ISO ===");

    foreach (IsoDirectoryRecord rootEntry in fs.ListRoot())
    {
        if (rootEntry.FileIdentifier.Length == 1 && rootEntry.FileIdentifier[0] <= '\u0001')
            continue;

        string size = rootEntry.IsDirectory ? "<DIR>" : rootEntry.DataLength.ToString();
        Console.WriteLine($"{size,12}  {rootEntry.FileIdentifier}");
    }
    
    Console.WriteLine();
    Console.WriteLine("=== Procurando código MIPS dentro dos arquivos da ISO ===");

    foreach (IsoDirectoryRecord packEntry in fs.ListRoot())
    {
        if (packEntry.IsDirectory || packEntry.FileIdentifier.Length <= 1)
            continue;

        string packName = IsoFileSystem.NormalizeName(packEntry.FileIdentifier);

        if (packName == "SLUS_203.47" || packName == "SYSTEM.CNF")
            continue;

        const int chunkSectors = 4096; // 8 MB por leitura
        long packRemaining = packEntry.DataLength;
        int packSector = checked((int)packEntry.ExtentLocation);
        long prologueHits = 0;

        while (packRemaining > 0)
        {
            int chunkSize = (int)Math.Min(packRemaining, chunkSectors * 2048L);
            byte[] chunk = iso.ReadBytes(packSector, chunkSize);

            int chunkWords = chunkSize / 4;

            for (int w = 0; w < chunkWords - 9; w++)
            {
                uint rawWord = BitConverter.ToUInt32(chunk, w * 4);
                uint topBits = rawWord & 0xFFFF0000;

                if ((topBits != 0x27BD0000 && topBits != 0x67BD0000) ||
                    (rawWord & 0x8000) == 0)
                    continue;

                for (int step = 1; step <= 8; step++)
                {
                    uint nextTop = BitConverter.ToUInt32(chunk, (w + step) * 4) & 0xFFFF0000;

                    if (nextTop == 0xFFBF0000 ||
                        nextTop == 0xAFBF0000 ||
                        nextTop == 0x7FBF0000)
                    {
                        prologueHits++;
                        break;
                    }
                }
            }

            packRemaining -= chunkSize;
            packSector += chunkSectors;
        }

        Console.WriteLine(
            $"{packName,-14} {packEntry.DataLength / 1048576.0,9:F1} MB  prólogos={prologueHits}");
    }
    
    Console.WriteLine();
    Console.WriteLine("=== Chamadas para endereços fora do ELF ===");

    foreach (MipsFunction callerFunction in scanProgram.Functions.Values)
    {
        foreach (MipsBasicBlock callerBlock in callerFunction.BasicBlocks)
        {
            if (!callerBlock.CallTarget.HasValue)
                continue;

            uint callTarget = callerBlock.CallTarget.Value;

            if (image.FindRegion(callTarget, 4) != null)
                continue;

            int callerIndex = Math.Max(0, callerBlock.Instructions.Count - 2);

            Console.WriteLine(
                $"0x{callerBlock.StartAddress + (uint)(callerIndex * 4):X8} " +
                $"(função 0x{callerFunction.StartAddress:X8}) chama 0x{callTarget:X8}");
        }
    }
    
    Console.WriteLine();
    Console.WriteLine("=== PKFINFO.TBL (primeiros 256 bytes) ===");

    byte[] pkInfo = fs.ReadFile("PKFINFO.TBL");

    for (int row = 0; row < 256 && row < pkInfo.Length; row += 16)
    {
        int rowLength = Math.Min(16, pkInfo.Length - row);

        Console.WriteLine(
            $"{row:X4}  {BitConverter.ToString(pkInfo, row, rowLength).Replace('-', ' ')}");
    }
    
    Console.WriteLine();
    Console.WriteLine("=== Disassembly da função 0x0048F488 ===");

    if (scanProgram.TryGetFunction(0x0048F488, out MipsFunction? inspected) &&
        inspected != null)
    {
        foreach (MipsBasicBlock inspectedBlock in
                 inspected.BasicBlocks.OrderBy(blk => blk.StartAddress))
        {
            for (int n = 0; n < inspectedBlock.Instructions.Count; n++)
            {
                uint at = inspectedBlock.StartAddress + (uint)(n * 4);
                MipsInstruction ins = inspectedBlock.Instructions[n];

                Console.WriteLine($"0x{at:X8}  {ins.Raw:X8}  {ins.Assembly}");
            }

            Console.WriteLine();
        }
    }
    
    return 0;
}
catch (Exception ex) when (
    ex is InvalidDataException ||
    ex is NotSupportedException ||
    ex is FileNotFoundException ||
    ex is EndOfStreamException)
{
    Console.WriteLine($"Erro: {ex.Message}");
    return 1;
}
